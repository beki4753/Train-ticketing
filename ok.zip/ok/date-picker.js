
// Initialize Flatpickr
//

// Hide the original date input element
