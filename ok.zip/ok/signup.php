<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>signup</title>
    <link rel="stylesheet" href="signup.css">
    <link rel="stylesheet" href="style.css">
    <script type="text/javascript" src="up.js"></script>
</head>
<body class="body">

<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php">Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="services.php">Services</a></li>
          </ul>
        </nav>
      </div>
    </header>


    
<h2 class="ddh">Create Your Account</h2>
      <form action="signupconn.php" class="ddi" name='hh' onSubmit="return Valid();" method="post">
            <input type="text" placeholder="First Name" class="dis" name="fname"> <br><br>
            <input type="text" placeholder="Last Name" class="dis" name="lname"><br><br>
            <input type="email" placeholder="your@email.com" class="dis" name="email"><br><br>
            <input type="phone" placeholder="Phone Number" class="dis" name="phone" max="10"><br><br>
            <input type="password" placeholder="password" class="dis" name="pass"  >
            <p >use 6 or more characters</p>
            <input type="address" placeholder="Address" class="dis" name="address"><br><br><br><br>
            <input type="reset" name="reset" class="st" ><br><br><br>
            <input type="submit" class="st" value="Create Account" >
        
        <h4 >already have account, <a title="If you have an account click here" href="login.php" class="aa">login</a> </h4>
          </form> 
   
</body>
</html>