<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>customer announcement</title>
    <link rel="stylesheet" type="text/css" href="customerannouncement.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="beauty.css">
    <link href="./Admin/plugins/summernote/summernote.css" rel="stylesheet" />

  </head>
<body >


<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="customerannouncement.php">Announcment</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="adminlog.php">Login</a></li>
            <li><a href="./Admin/send.php" id="send">Pay</a></li>
          </ul>
        </nav>
      </div>
    </header>

<pre class="body">
<br/>
<br/>



<?php 
$db = mysqli_connect("localhost", "root", "", "project");
$sql = "SELECT * FROM images";
$result = mysqli_query($db, $sql);
while ($row = mysqli_fetch_array($result)){
    echo "<div class='row mb-5'>";
        echo "<div class='col-md-6'>";
            echo "<img src='./images/".$row['image']. "' class='img-fluid' alt='Announcement Image'>";
        echo "</div>"; 
        echo "<div class='col-md-6'>";
            echo "<p class='lead'>".$row['text']. "</p>";
        echo "</div>";
    echo "</div>";
}

   

        

    ?>  
</pre>


        <footer>
     
               <span class=" __">
                
            <i> Email:</i> &nbsp;&nbsp;&nbsp;
            <a href="https:// www.gmail.com/brackgech@gmail.com" style="color: blue;">brackgech@gmail.com</a>
            <p style="margin-left: -99px; "> <i> mail Box:</i>  &nbsp; 72071</p>
                       
            
            <p style="margin-left: 74px; "><i> Tel:</i> &nbsp;+046 221 08 60/61 &nbsp;
                                            +011 234 40 32/30<p>
            
               Train Ticketing, Copyright &copy; 2022 
            </p>
             
           </span>  
         </p>
    </footer>
    <script src="beauty.js"></script>
    
    <script>
            var resizefunc = [];
        </script>
    <script src="./Admin/assets/js/jquery.min.js"></script>
        <script src="./Admin/assets/js/bootstrap.min.js"></script>
        <script src="./Admin/assets/js/detect.js"></script>
        <script src="./Admin/assets/js/fastclick.js"></script>
        <script src="./Admin/assets/js/jquery.blockUI.js"></script>
        <script src="./Admin/assets/js/waves.js"></script>
        <script src="./Admin/assets/js/jquery.slimscroll.js"></script>
        <script src="./Admin/assets/js/jquery.scrollTo.min.js"></script>
        <script src="./Admin/plugins/switchery/switchery.min.js"></script>
    <script src="./Admin/plugins/summernote/summernote.min.js"></script>
        <!-- Select 2 -->
        <script src="./Admin/plugins/select2/js/select2.min.js"></script>
        <!-- Jquery filer js -->
        <script src="./Admin/plugins/jquery.filer/js/jquery.filer.min.js"></script>

        <!-- page specific js -->
        <script src="./Admin/assets/pages/jquery.blog-add.init.js"></script>
    <script src="./Admin/assets/js/jquery.core.js"></script>
        <script src="./Admin/assets/js/jquery.app.js"></script>
    <script>

jQuery(document).ready(function(){

    $('.summernote').summernote({
        height: 240,                 // set editor height
        minHeight: null,             // set minimum height of editor
        maxHeight: null,             // set maximum height of editor
        focus: false                 // set focus to editable area after initializing summernote
    });
    // Select2
    $(".select2").select2();

    $(".select2-limiting").select2({
        maximumSelectionLength: 2
    });
});
</script>
<script src="./Admin/plugins/switchery/switchery.min.js"></script>

<!--Summernote js-->
<script src="./Admin/plugins/summernote/summernote.min.js"></script>
<script src="./Admin/plugins/jquery.filer/js/jquery.filer.min.js"></script>

</body>
</html>