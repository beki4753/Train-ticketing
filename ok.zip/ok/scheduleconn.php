<?php
$fromm =$_POST['source'];
$too =$_POST['destination'];
$time =$_POST['time'];
$datee =$_POST['datee'];

$Itime=new DateTime($time, new DateTimeZone("Africa/Addis_Ababa"));
$Ethiopian_time=$Itime->format("h:i A");
echo '<script>';
echo 'alert("$Ethiopian_time");';
echo '<?script>';
//database connection
$conn = new mysqli('localhost','root','','project');
if($conn->connect_error){
	die('Connection Failed : '.$conn->connect_error);
}else{
       try{
	$stmt = $conn->prepare("insert into schedule(source,destination,date,time)
		values(?,?,?,?)");
	$stmt->bind_param("ssss",$fromm,$too,$datee,$Ethiopian_time);
	$stmt->execute();
 
	echo '<script>';
	echo 'alert("inserted successfully...");';
	echo '</script>';
	$stmt->close();
	$conn->close();
	header("Location: schedulform.php");
       }catch(Exception $e){
		echo '<script>';
       	echo 'alert("Message"'.$e->getMessage().');';
		   echo '</script>';
		   header("Location: schedulform.php");

       }

}
?>