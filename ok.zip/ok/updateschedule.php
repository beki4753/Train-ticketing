<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
</head>
<body >
	
		<div class="container">
          <form action="update.php" method="get">

            <label title="to be updated" style="color: #fff;">Enter Date Of:</label>
            <input type="date" name="datee"><br><br>
              <p style="color: #fff;">Insert New Data</p>
        <label style="color: #fff;">Origin</label>
         <select name="source" id="s">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select><br><br>
        <label style="color: #fff;">     Destination</label>
         <select name="destination" id="d">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select><br><br>
        <input type="time" name="time" placeholder="Time" required=""><br><br>
      
        <input type="reset" name="reset" value="reset">
        <input type="submit" name="update" onclick="abc()">
            <script type="text/javascript">

            function abc(){
                selectElement=document.querySelector('#s');
                var a=selectElement.value;
                selectElement=document.querySelector('#d');
            var b=selectElement.value;
            
           
                            if (a === b) {
                 window.alert("Incorrect selection Select correctly!!");
                 window.location.replace("updateschedule.php");
            }
            }
            

        </script>
    </form>

        </div>
		

</body>
</html>
<?php
if(isset($_POST["search"])){
    require "update.php";
}
?>