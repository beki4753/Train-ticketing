const form1 = document.getElementById('myform');
const nameInput = document.querySelector('input[name="Name"]');
const nameInput1 = document.getElementById('name');
const emailInput = document.querySelector('input[name="Email"]');
const emailInput1 = document.getElementById('email');
const select1 = document.querySelector('select[name="origin"]');
const select2 = document.querySelector('select[name="destination"]');
const txnIdInput = document.querySelector('input[name="ttno"]');
const txnIdInput1 = document.getElementById('tno');
var num =0;
var num1 =0;
var num2 =0;
var num3 =0;
var num4 =0;
var num5 =0;
const dateInput = document.getElementById("date");
const txnInput = document.getElementById("tno");
const phoneField = document.getElementById("tel"); 

form1.addEventListener('submit', (event) => {
  event.preventDefault();
  nameInput1.addEventListener("input", function(event) { 
    const name = event.target.value; 
  if (!isValidname(name)) { 
    num =1;
    nameInput1.setCustomValidity("Name field must contain only alphabet characters."); 
  } else { nameInput1.setCustomValidity(""); } 
  }); 
  function isValidname(name) { 
    const nameRegex = /^[a-zA-Z\s]+$/; 
    return nameRegex.test(name); 
  }
  
  emailInput1.addEventListener("input", function(event) { 
    const email = event.target.value; 
  if (!isValidemail(email)) { 
    num1=1;
  emailInput1.setCustomValidity("Email field must be a valid email address."); 
  } else { emailInput1.setCustomValidity(""); } 
  }); 
  function isValidemail(email) { 
    const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
    return emailRegex.test(email); 
  }
  
  phoneField.addEventListener("input", function(event) { 
      const phone = event.target.value; 
  if (!isValidPhone(phone)) { 
    num2=1;
      phoneField.setCustomValidity("Please enter a valid phone number starting with +251"); 
  } else { phoneField.setCustomValidity(""); } 
  }); 
  function isValidPhone(phone) { 
      const phoneRegex = /^\+251\d{9}$/; 
      return phoneRegex.test(phone); 
  }
  
  
  dateInput.addEventListener("input", (event) => {
    const currentDate = new Date();
    const inputDate = new Date(event.target.value);
    if (inputDate < currentDate) {
      num3=1;
      event.target.setCustomValidity("Invalid date");
    } else {
      event.target.setCustomValidity("");
    }
  });
  
  // Add event listener for the transaction number input field
  txnInput.addEventListener("input", (event) => {
    const inputString = event.target.value;
    const regex = /^[A-Za-z0-9]+$/;
    if (!regex.test(inputString)) {
      num4=1;
      event.target.setCustomValidity("Invalid transaction number");
    } else if(!isValidtxn(inputString)){
      num=1;
     event.target.setCustomValidity("Txn id must be 10."); 
    }else {
      event.target.setCustomValidity("");
    }
  
  });
  function isValidtxn(inputString) { 
    if(inputString.length <= 10) {
   return true;
   }else{
     return false; 
   }
   }
  //const nameValue = nameInput.value.trim();
  //const emailValue = emailInput.value.trim();
  const select1Value = select1.value;
  const select2Value = select2.value;
  //const txnIdValue = txnIdInput.value.trim();

  //const namePattern = /^[a-zA-Z\s]+$/;
  //const emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

 let errors = [];
 
  // if (!namePattern.test(nameValue)) {
  //   //errors.push('Name field must contain only alphabet characters.');
  //   nameInput1.setCustomValidity("Name field must contain only alphabet characters."); 
  // }

  // if (!emailPattern.test(emailValue)) {
  // //  errors.push('Email field must be a valid email address.');
  // emailInput1.setCustomValidity("Email field must be a valid email address."); 

  // }

  if (select1Value === select2Value) {
    num5=1
    errors.push('Origin or destination error selection must not be the same');
  }

  // if (txnIdValue.length <= 10) {
  //   //errors.push('Txn id must not be less than 10.');
  //   txnIdInput1.setCustomValidity("Txn id must not be less than 10."); 

  // }

  if (errors.length > 0) {
    alert(errors.join('\n'));
  } else if(num!==1 && errors.length === 0){
    if(num1!==1){
    if(num2!==1){
    if(num3!==1){
    if(num4!==1){
    if(num5!==1){
    form1.submit();
    }
    }
    }
    }
    }
  }
});
