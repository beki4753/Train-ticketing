<?php

// better option
$pas="admin";
$options = ['bemejemeriya kal nebere kalm be egziyabehr zend nebere kalm egziyabehr nebere' => 12];
$hashedpass=password_hash($pas, PASSWORD_BCRYPT, $options);






//less options
$pas2 =base64_encode($pas);
$k=md5($pas2);
$s=md5($k);
echo '<script>';
echo 'alert("'.$hashedpass.'");';
echo '</script>';

?>