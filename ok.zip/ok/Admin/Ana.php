<?php
session_start();
    $msg = "";
    if (isset($_POST['upload'])){
        $targetDir = "./images/";
        $targetFile = $targetDir . basename($_FILES['image']['name']);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    
        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check === false) {
            die("File is not an image.");
        }
    
        // Check file size
        if ($_FILES['image']['size'] > 5000000) {
            die("Sorry, your file is too large.");
        }
    
        // Allow certain file formats
        if ($imageFileType !== "jpg" && $imageFileType !== "png" && $imageFileType !== "jpeg" && $imageFileType !== "gif") {
            die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
        }
    
        // Move uploaded file to target directory
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            die("Sorry, there was an error uploading your file.");
        }
    
        $conn = mysqli_connect("localhost", "root", "", "project");
    
        // Sanitize and escape user input to prevent SQL injection
        $image = mysqli_real_escape_string($conn, basename($_FILES['image']['name']));
        $text = mysqli_real_escape_string($conn, $_POST['text']);

            $sql = "INSERT INTO images (image, text,Is_Active) VALUES ('$image', '$text',1)";
            if(mysqli_query($conn, $sql)) {
                echo '<script>';
                echo 'alert("Record added successfully.");';
                echo 'window.location.href="addAnnouncment.php";';
                echo '</script>';
            }else {
                echo "Error: " . mysqli_error($conn);
            }
        
      
    // }else{
        // echo '<script>';
        // echo 'alert("Failed! duplicated Entry.");';
        // echo '</script>';
    // }
        mysqli_close($conn);
    }
     
?>

<?php
include('./includes/config.php');
    //<b>Train metro ticketing company</b> invites vallified applicants for the above position
    //<b>this is urgent</b>
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">
        <!-- App title -->
        <title>Admin | Dashboard</title>
       <!-- App favicon -->
       <link rel="shortcut icon" href="./assets/images/favicon.ico">
        <!-- App title -->
        <title>DU Radio | Add Post</title>

        <!-- Summernote css -->
        <link href="./plugins/summernote/summernote.css" rel="stylesheet" />

        <!-- Select2 -->
        <link href="./plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />

        <!-- Jquery filer css -->
        <link href="./plugins/jquery.filer/css/jquery.filer.css" rel="stylesheet" />
        <link href="./plugins/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet" />

        <!-- App css -->
        <link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="./plugins/switchery/switchery.min.css">
        <script src="./assets/js/modernizr.min.js"></script>
<style>
.img-fluid{
    width: 50vw;
    height: 70vh;
    display: block;
    border: 1px solid rgba(0,0,0,0.1);
}
.row{
    display: flex;
    flex-wrap:wrap;
    /* align-items: center;
    justify-content: center; */
}
.lead{
    display: flex;
    flex-wrap: wrap;
    float: left;
}
.col-md-6{
    display: block;
    position: relative;
    margin-left: 15vw;
}
@media screen and (max-width: 600px){
    .col-md-6{
    margin-left: auto;
}
.img-fluid{
    width: 90vw;
    height: 70vh;
}
}
</style>
    </head>


    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
   
        <?php 
$db = mysqli_connect("localhost", "root", "", "project");
$sql = "SELECT * FROM images";
$result = mysqli_query($db, $sql);
while ($row = mysqli_fetch_array($result)){
    echo "<div class='row mb-5'>";
        echo "<div class='col-md-6'>";
            echo "<img src='./images/".$row['image']. "' class='img-fluid' alt='Announcement Image'>";
        echo "</div>"; 
        echo "<div class='col-md-6'>";
            echo "<p class='lead'>".$row['text']. "</p>";
        echo "</div>";
    echo "</div>";
}

   

        

    ?>           

                    </div> <!-- container -->

                </div> <!-- content -->


            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


 

        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="./assets/js/jquery.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script src="./assets/js/detect.js"></script>
        <script src="./assets/js/fastclick.js"></script>
        <script src="./assets/js/jquery.blockUI.js"></script>
        <script src="./assets/js/waves.js"></script>
        <script src="./assets/js/jquery.slimscroll.js"></script>
        <script src="./assets/js/jquery.scrollTo.min.js"></script>
        <script src="./plugins/switchery/switchery.min.js"></script>

        <!--Summernote js-->
        <script src="./plugins/summernote/summernote.min.js"></script>
        <!-- Select 2 -->
        <script src="./plugins/select2/js/select2.min.js"></script>
        <!-- Jquery filer js -->
        <script src="./plugins/jquery.filer/js/jquery.filer.min.js"></script>

        <!-- page specific js -->
        <script src="./assets/pages/jquery.blog-add.init.js"></script>

        <!-- App js -->
        <script src="./assets/js/jquery.core.js"></script>
        <script src="./assets/js/jquery.app.js"></script>

        <script>

            jQuery(document).ready(function(){

                $('.summernote').summernote({
                    height: 240,                 // set editor height
                    minHeight: null,             // set minimum height of editor
                    maxHeight: null,             // set maximum height of editor
                    focus: false                 // set focus to editable area after initializing summernote
                });
                // Select2
                $(".select2").select2();

                $(".select2-limiting").select2({
                    maximumSelectionLength: 2
                });
            });
        </script>
  <script src="./plugins/switchery/switchery.min.js"></script>

        <!--Summernote js-->
        <script src="./plugins/summernote/summernote.min.js"></script>
    </body>
</html>