<?php
session_start();
include('./includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">
        <!-- App title -->
        <title>Admin | Add Schedule</title>
		<link rel="stylesheet" href="./plugins/morris/morris.css">

        <!-- App css -->
        <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">

        <link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="./plugins/switchery/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="../s.css">
        <script src="./assets/js/modernizr.min.js"></script>
<style>
.form-control:focus {
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
</style>
    </head>
    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.html" class="logo"><span>NP<span>Admin</span></span><i class="mdi mdi-layers"></i></a>
                    <!-- Image logo -->
                    <!--<a href="index.html" class="logo">-->
                        <!--<span>-->
                            <!--<img src="../assets/images/logo.png" alt="" height="30">-->
                        <!--</span>-->
                        <!--<i>-->
                            <!--<img src="../assets/images/logo_sm.png" alt="" height="28">-->
                        <!--</i>-->
                    <!--</a>-->
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
            <?php include('./includes/topheader.php');?>
            </div>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->
    <?php include('./includes/leftsidebar.php');?>
            <!-- Left Sidebar End -->



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                    <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Add Schedule </h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Admin</a>
                                        </li>
                                        <li>
                                            <a href="#">Schedules</a>
                                        </li>
                                        <li class="active">
                                        Add Schedule 
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
  <div class="row">
    <div class="col-md-6 mx-auto">
      <form action="" method="post" id="myform" >
        <div class="form-group">
          <label for="source">Origin:</label>
          <select name="source" id="source" class="form-control">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option value="Alisabeh">Alisabeh</option>
            <option value="Nagada">Nagada</option>
          </select>
        </div>
        <div class="form-group">
          <label for="destination">Destination:</label>
          <select name="destination" id="destination" class="form-control">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option value="Alisabeh">Alisabeh</option>
            <option value="Nagada">Nagada</option>
          </select>
        </div>
        <div class="form-group">
          <label for="time">Time:</label>
          <input type="time" name="time" id="time" class="form-control" placeholder="Time" required>
        </div>
        <div class="form-group">
          <label for="date">Date:</label>
          <input type="date" name="date" id="date" class="form-control" required>
        </div>
        <div class="form-group">
          <input type="reset" name="reset" value="Reset" class="btn btn-secondary">
          <input type="submit" name="insert" class="btn btn-primary">
        </div>
        <script type="text/javascript">

const form = document.getElementById("myform");
const dateInput = document.querySelector('#date');
//action="search.php"
let dbool=false;
let sbool=false;
dateInput.addEventListener("input", (event) => {
  const currentDate = new Date();
  const inputDate = event.target.value;
  const dateParts = inputDate.split("-");
  const year = parseInt(dateParts[0]);
  let month = parseInt(dateParts[1]) - 1; // month is 0-based
  let day = parseInt(dateParts[2]) + 1;
  
  // Check if the current month has 31 days
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  if (daysInMonth === 31 && day === 31) {
    day = 1;
    month++;
  }

  const datenew = new Date(year, month, day);
  const timezoneOffset = datenew.getTimezoneOffset() * 60 * 1000; // in milliseconds
  datenew.setTime(datenew.getTime() + timezoneOffset);

  if (datenew.getTime() < currentDate.getTime()) {
    event.target.setCustomValidity("Invalid date");
  } else {
    event.target.setCustomValidity("");
    dbool = true;
  }
});





const origin = document.getElementById('source');
const destination = document.getElementById('destination');

let prevOrigin = origin.value;
let prevDestination = destination.value;

form.addEventListener('change', (event) => {
  if (event.target === origin) {
    prevOrigin = origin.value;
  } else if (event.target === destination) {
    prevDestination = destination.value;
  }
  
  if (prevOrigin === prevDestination) {
    event.preventDefault();
    destination.setCustomValidity('Please select a different destination');
  } else {
    destination.setCustomValidity('');
  }
});


form.addEventListener('submit', (event) => {
  const inputs = form.querySelectorAll('input');

  // Check if any input has invalid value
  const hasInvalidInput = Array.from(inputs).some((input) => !input.checkValidity());

  if (hasInvalidInput) {
    // Prevent form submission
    event.preventDefault(); 
    alert('Some Thing went Wrong');  
  }
});

 </script>
      </form>
    </div>
  </div>
</div>




            </div>
            <!-- /Right-bar -->

        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="./assets/js/jquery.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script src="./assets/js/detect.js"></script>
        <script src="./assets/js/fastclick.js"></script>
        <script src="./assets/js/jquery.blockUI.js"></script>
        <script src="./assets/js/waves.js"></script>
        <script src="./assets/js/jquery.slimscroll.js"></script>
        <script src="./assets/js/jquery.scrollTo.min.js"></script>
        <script src="./plugins/switchery/switchery.min.js"></script>

        <!-- Counter js  -->
        <script src="./plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="./plugins/counterup/jquery.counterup.min.js"></script>

        <!--Morris Chart-->
		<script src="./plugins/morris/morris.min.js"></script>
		<script src="./plugins/raphael/raphael-min.js"></script>

        <!-- Dashboard init -->
        <script src="./assets/pages/jquery.dashboard.js"></script>

        <!-- App js -->
        <script src="./assets/js/jquery.core.js"></script>
        <script src="./assets/js/jquery.app.js"></script>
	
		
</body>
</html>
<?php
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// $fromm = $_POST['source'];
// $too = $_POST['destination'];
// $time = $_POST['time'];
// $datee = $_POST['date'];
// //if(isset())
// $Itime = new DateTime($time, new DateTimeZone("Africa/Addis_Ababa"));
// $Ethiopian_time = $Itime->format("h:i");
// var_dump($Ethiopian_time);

//database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die('Connection Failed : ' . $conn->connect_error);
}

// Check if data already exists
$query = "SELECT id FROM schedule WHERE source = ? AND destination = ? AND date = ? AND time = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssss", $source, $destination, $date, $time);

$source = $_POST['source'];
$destination = $_POST['destination'];
$date = $_POST['date'];
$time = $_POST['time'];

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Data already exists, show error message
    echo '<script>';
    echo 'alert("Schedule failed: duplicate data...");';
    echo '</script>';
} else {
    // Data doesn't exist, insert new row
    $stmt = $conn->prepare("INSERT INTO schedule (id, source, destination, date, time, Is_Active) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssi", $id, $source, $destination, $date, $time, $is_active);

    $id = '';
    $is_active = 1;

    if (!$stmt->execute()) {
        // Insertion failed, show error message
        echo '<script>';
        echo 'alert("Schedule failed: ' . mysqli_error($conn) . '");';
        echo '</script>';
    } else {
        // Insertion successful, show success message
        echo '<script>';
        echo 'alert("Scheduled successfully...");';
        echo '</script>';
    }


$stmt->close();
$conn->close();


        header("Location: schedulform.php");
    // } catch (Exception $e) {
    //     echo '<script>';
    //     echo 'alert("Message"'.$e->getMessage().');';
    //     echo '</script>';
    //     header("Location: schedulform.php");
    // }
}
 }
?>
