<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";
$conn = new mysqli($servername, $username, $password, $dbname);
// Validate input
if (isset($_POST['name']) && isset($_POST['txn'])) {
  $request_id = htmlentities($_POST['name']);
  $transaction_number =htmlentities($_POST['txn']);
  // echo '<script>';
  // echo 'alert("'.$transaction_number .'");';
  // echo '</script>';
  // TODO: Handle database insert/update with request ID and transaction number
  $request_sql = "SELECT Request_Id FROM request WHERE Request_Id='$request_id'";
  $request_result = $conn->query($request_sql);
  $err="";
  $msg="";
  if($request_result->num_rows > 0) {
    $checked_sql = "SELECT Txn_Id FROM trans_xn WHERE Txn_Id='$transaction_number'";
    $checked_result = $conn->query($checked_sql);
    if($checked_result->num_rows > 0) {
      $err ="Allredy Sent!";
    }else{
      $checked_sql = "INSERT INTO `trans_xn`(`Id`,`Txn_Id`,`Request_Id`) 
      VALUES ('','$transaction_number','$request_id')";
      $checked_result = $conn->query($checked_sql);
      if($checked_result) {
        // echo '<script>';
        // echo 'alert("Sent!! Wait for SMS confirmation");';
        // echo '</script>';
        $msg ="Sent!! Wait for SMS confirmation";
      }else {
        // echo '<script>';
        // echo 'alert("Some thing went wrong please try again");';
        // echo '</script>';
        $err ="Sent!! Wait for SMS confirmation";
      }
    }
  }else{
    $err="Incorrect Code";
  }

 
    
    if(strlen($err)>0){
      header("Location: send.php?error=$err && action=err");
      }else if(strlen($msg)>0){
      header("Location: send.php?msg=$msg && action=succ");
  }else{
    $err="some thing went wrong!";
    header("Location: send.php?error=$err && action=err");

  }

}
?>
