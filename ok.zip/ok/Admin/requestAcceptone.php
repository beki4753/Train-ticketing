<?php
session_start();
include('./includes/config.php');
error_reporting(0);

if(strlen($_SESSION['login'])==0)
  { 
header('location: ./index.php');
}else{
  if($_GET['action']=='del')
{
$postid=intval($_GET['pid']);
$query=mysqli_query($con2,"update schedule set Is_Active=0 where id='$postid'");
if($query)
{
$msg="Post deleted ";
}
else{
$error="Something went wrong . Please try again.";    
} 
}

if($_GET['action']=='succ')
{
$msg=strval($_GET['msg']);
}

if($_GET['action']=='err'){
$error=strval($_GET['error']);    
} 
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App favicon -->
        <link rel="shortcut icon" href="./assets/images/favicon.ico">
        <!-- App title -->
        <title>Admin | Manage Schedule</title>

        <!--Morris Chart CSS -->
		<link rel="stylesheet" href="./plugins/morris/morris.css">

        <!-- jvectormap -->
        <link href="./plugins/jvectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

        <!-- App css -->
        <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">

<link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/core.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/components.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/pages.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/menu.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/responsive.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="./plugins/switchery/switchery.min.css">
<script src="./assets/js/modernizr.min.js"></script>

    </head>


    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
           <?php include('./includes/topheader.php');?>

            <!-- ========== Left Sidebar Start ========== -->
           <?php include('./includes/leftsidebar.php');?>


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                                        
                  
                    <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">   Guest Request  </h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Admin</a>
                                        </li>
                                        <li>
                                            <a href="#">Accept</a>
                                        </li>
                                        <li class="active">
                                        Guest Request 
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->
                        <div class="row">
<div class="col-sm-6">  
<!---Success Message--->  
<?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo htmlentities($msg);?>
</div>
<?php } ?>

<!---Error Message--->
<?php if($error){ ?>
<div class="alert alert-danger" role="alert">
<strong>Oh snap!</strong> <?php echo htmlentities($error);?></div>
<?php } ?>


</div>
</div>
<!-- Table start -->
<div class="row">
  <div class="col-sm-12">
    <div class="card-box">
      <div class="table-responsive">
        <table class="table table-colored table-centered table-inverse m-0">
          <thead>
            <tr>    
        <th>Name</th>
        <th>Number</th>
        <th>Date</th>
        <th>Origin</th>
        <th>Destination</th>
        <th>Payment_Id</th>
        <th>Action</th>

            </tr>
          </thead>
          <tbody>
            <?php  
  $query=mysqli_query($con2,"SELECT r.Request_Id as postid, r.name as name, r.num_person as bizat, r.date as ken, r.source as menesha, r.destination as medresha, t.Txn_Id as kfya
  FROM request r
  LEFT JOIN trans_xn t ON r.Request_Id = t.Request_Id
  WHERE NOT EXISTS (
    SELECT 1 FROM checked c WHERE c.Request_Id = r.Request_Id
  )
  ");
  
  $rowcount=mysqli_num_rows($query);
  if($rowcount==0 ) {
?>
    <tr>
      <td colspan="4" align="center">
        <h3 style="color:red">No record found</h3>
      </td>
    </tr>
  <?php 
  } else {
    while($row=mysqli_fetch_array($query)) {
  ?>
      <tr>
        <td><b><?php echo htmlentities($row['name']);?></b></td>
        <td><?php echo htmlentities($row['bizat'])?></td>
        <td><?php echo htmlentities($row['ken'])?></td>
        <td><?php echo htmlentities($row['menesha'])?></td>
        <td><?php echo htmlentities($row['medresha'])?></td>
        <td><?php echo htmlentities($row['kfya'])?></td>
        <td><a href="checked.php?pid=<?php echo htmlentities(base64_encode($row['postid']));?>&&action=check"><i class="mdi mdi-check"></i></a> 
&nbsp;<a href="canceled.php?pid=<?php echo htmlentities(base64_encode($row['postid']));?>&&action=cancel" onclick="return confirm('Do you realy want to cancel?')"> <i class="mdi mdi-close"></i></a> </td>
</tr>
<?php } }?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- Table End -->




                    </div> <!-- container -->

                </div> <!-- content -->

       <?php include('../includes/footer.php');?>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

<script src="./assets/js/jquery.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script src="./assets/js/detect.js"></script>
        <script src="./assets/js/fastclick.js"></script>
        <script src="./assets/js/jquery.blockUI.js"></script>
        <script src="./assets/js/waves.js"></script>
        <script src="./assets/js/jquery.slimscroll.js"></script>
        <script src="./assets/js/jquery.scrollTo.min.js"></script>
        <script src="./plugins/switchery/switchery.min.js"></script>

        <!-- Counter js  -->
        <script src="./plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="./plugins/counterup/jquery.counterup.min.js"></script>

        <!--Morris Chart-->
		<script src="./plugins/morris/morris.min.js"></script>
		<script src="./plugins/raphael/raphael-min.js"></script>

        <!-- Dashboard init -->
        <script src="./assets/pages/jquery.dashboard.js"></script>

        <!-- App js -->
        <script src="./assets/js/jquery.core.js"></script>
        <script src="./assets/js/jquery.app.js"></script>

    </body>
</html>
<?php } ?>