
<?php

// function generateUniqueNumber($db) {
//     $newNumber = strval(mt_rand(100000000000, 999999999999));
//     $query = "SELECT Ticket_Id FROM ticket WHERE Ticket_Id = '$newNumber'";
//     $result = mysqli_query($db, $query);
  
//     if(mysqli_num_rows($result) > 0) {
//         // if the number is already in the database, generate a new one
//         $newNumber = generateUniqueNumber($db);
//     }
    
//     return $newNumber;
// }


if($_GET['action']='check') {
    $postid = intval(base64_decode($_GET['pid']));  
    
    $db = mysqli_connect('localhost', 'root', '', 'project');
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "project";
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // SELECT request information
    $request_sql = "SELECT Request_Id,phone,date,num_person,source,destination FROM request WHERE Request_Id='$postid'";
    $request_result = $conn->query($request_sql);
    
    if($request_result->num_rows > 0) {
        while($row = $request_result->fetch_assoc()) {
            $request_id = $row['Request_Id'];
            $phone = $row['phone'];
            $date = $row['date'];
            $num_person = $row['num_person'];
            $source = $row['source'];
            $destination = $row['destination'];
            
            // SELECT schedule time
            $schedule_sql = "SELECT time FROM schedule WHERE source=? AND destination=? AND date=?";
            $schedule_stmt = $conn->prepare($schedule_sql);
            $schedule_stmt->bind_param("sss", $source, $destination, $date);
            $schedule_stmt->execute();
            $schedule_result = $schedule_stmt->get_result();
            
            // $sql = "SELECT time FROM schedule WHERE source = ? AND destination = ? AND date = ?";
            // $stmt = $conn->prepare($sql);
            // $stmt->bind_param("sss", $source, $destination, $date);
            // $stmt->execute();
            // $result = $stmt->get_result();

            if($schedule_result->num_rows > 0) {
                while($schedule = $schedule_result->fetch_assoc()) {
                    $time = $schedule['time'];
                    
                    // SELECT train ID
                    $train_sql = "SELECT Train_id FROM train";
                    $train_result = $conn->query($train_sql);
                    
                    if($train_result->num_rows > 0) {
                        while($train = $train_result->fetch_assoc()) {
                            $train_id = $train['Train_id'];
                            
                            // generate unique ticket ID
                            $ticket_id = uniqid();
                            $verification_code = substr(bin2hex(random_bytes(16)),0,12);
                            $newNumber = strval(mt_rand(100000000000, 999999999999));
                            $ticket_query = "SELECT Ticket_Id FROM ticket WHERE Ticket_Id = '$newNumber'";
                            $ticket_result = mysqli_query($db, $ticket_query);
                            
                            // check if ticket ID is unique
                            while(mysqli_num_rows($ticket_result) > 0) {
                                $newNumber = strval(mt_rand(100000000000, 999999999999));
                                $ticket_query = "SELECT Ticket_Id FROM ticket WHERE Ticket_Id = '$newNumber'";
                                $ticket_result = mysqli_query($db, $ticket_query);
                            }
                            $checked_sql = "select * from `checked` where date='$date' and status='checked' and Request_Id='$request_id'";
                            $checked_result = $conn->query($checked_sql);
                            if($checked_result->num_rows>0){
                                $err="User alredy checked.";
                            }else{
                                $checked_sql = "INSERT INTO `checked`(`date`,`status`,`Request_Id`) 
                                VALUES ('$date','checked','$request_id')";
                                $checked_result = $conn->query($checked_sql);
                                if($checked_result) {
                                // INSERT ticket information
                                $ticket_sql = "select * from `ticket` where `Ticket_Id`='$newNumber' and `origin`='$source' and `destination`='$destination' and `date`='$date' and `time`='$time' and `person`='$num_person' and `Request_Id`='$request_id' and `Train_id`='$train_id'";
                                $ticket_result = $conn->query($ticket_sql);
                                if($ticket_result->num_rows>0){
                                    $err="Ticket exist.";
                                }else{
                                    $ticket_sql = "INSERT INTO `ticket`(`Ticket_Id`,`origin`,`destination`,`date`,`time`,`person`,`Request_Id`,`Train_id`) 
                                    VALUES ('$newNumber','$source','$destination','$date','$time','$num_person','$request_id','$train_id')";
                                    $ticket_result = $conn->query($ticket_sql);  
                                    if($ticket_result) {
        
                                        // $api_token = "1vdqBtpgAKzX2P2PRE4380QGSL8W9SjA";
                                        // $message = "Your Ticket Id Is: ".$newNumber." insert it with your Identification to the website and take your ticket.";
                                        
                                        // $data = array(
                                        //     'token' => $api_token,
                                        //     'phone' => $phone,
                                        //     'msg' => $message,
                                        //     'shortcode_id=9481',
                                        // );
                                        
                                        // $ch = curl_init('https://api.geezsms.com/api/v1/sms/send');
                                        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                        // curl_setopt($ch, CURLOPT_POST, true);
                                        // curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                                        // $result = curl_exec($ch);   
                                        // curl_close($ch);
                                        $msg="user Checked!";
                                    } else {
                                        $err= "Not Inserted!";
                                    }
                                }
    
                                } else {
                                    $err= "Not checked!";
                                }
                            }

                        }
                    } else {
                        $err= "No train found";
                    }
                }
            } else {
                $err= "No schedule found";
            }
        }
    } else {
        $err= "No request found";
    }

    if(strlen($err)>0){
    header("Location: requestAcceptone.php?error=$err && action=err");
    }else if(strlen($msg)>0){
    header("Location: requestAcceptone.php?msg=$msg && action=succ");
}
if(strlen($err)>0){
    $url = "requestAcceptone.php?error=$err&action=err";
    if (!headers_sent()) {
        header("Location: $url");
        exit;
    } else {
        echo "<script>location.href='$url';</script>";
        exit;
    }
} else if(strlen($msg)>0){
    $url = "requestAcceptone.php?msg=$msg&action=succ";
    if (!headers_sent()) {
        header("Location: $url");
        exit;
    } else {
        echo "<script>location.href='$url';</script>";
        exit;
    }
}
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

}



// function verify(){
//     $unique_id=uniqid();
//     //$verification_code=substr(bin2hex(random_bytes(16)),0,12);
//     $newNumber = strval(mt_rand(100000000000, 999999999999));
//     return  $newNumber;
// }
// $check=verify();

// function recu($check){
// $conn = new mysqli('localhost', 'root', '', 'project');

//     $sql = "SELECT * FROM verification WHERE code='$check'";
//     $result = $conn->query($sql);
//     if($result->num_rows > 0) {
//         $check=verify();
//        return recu($check);
//     }else{
//         return $check;
//     }
// }
// $_SESSION['verification']=$check;
// $checked=recu($check);
        // $sql="INSERT INTO `verification`(`code`) VALUES ('$checked')";
        // $result2=$conn->query($sql);  
        // if($result2) {
        //     echo "Inserted successfuly";
        // }else{
        //     echo "Not Inserted!";
        // }


//send sms goes

// $email=$_SESSION['family'];
// $sql = "SELECT `phone` FROM request WHERE email = '$email' ";
// $result = $conn->query($sql);

// if ($result->num_rows > 0) {

    // $api_token = "1vdqBtpgAKzX2P2PRE4380QGSL8W9SjA";
    // $from = "9481";
    // $to = "+251985818912";
    // $message = "sera eko uuuuu";
    
    // $data = array(
    //     'token' => $api_token,
    //     'phone' => $to,
    //     'msg' => $message,
    //     'shortcode_id=9481',
    // );
    
    // $ch = curl_init('https://api.geezsms.com/api/v1/sms/send');
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($ch, CURLOPT_POST, true);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    // $result = curl_exec($ch);   
    // curl_close($ch);
// }



// }

// for ticket id 
// function verify(){
//     $unique_id=uniqid();
//     $verification_code=substr(bin2hex(random_bytes(16)),0,12);
//     return $verification_code;
// }
// $check=verify();

// function recu($check){
//     $sql = "SELECT * FROM verification WHERE code='$check'";
//     $result = $conn->query($sql);
//     if($result->num_rows > 0) {
//         $check=verify();
//        return recu($check);
//     }
// }
// echo $check;
//         $sql="INSERT INTO `verification`(`code`) VALUES ('$check')";
//         $result2=$conn->query($sql);  
//         if($result2) {
//             echo "Inserted successfuly";
//         }else{
//             echo "Not Inserted!";
//         }

// 1000297200503   //1000382453631
// function generateUniqueNumber($db) {
//     $unique_id=uniqid();
//     $verification_code=substr(bin2hex(random_bytes(16)),0,12);
//     return $verification_code;


//     // generate a random 12-digit number
//     $newNumber = strval(mt_rand(100000000000, 999999999999));
  
//     // check if the number is already in the database
//     $query = "SELECT code FROM verification WHERE code = '$newNumber'";
//     $result = mysqli_query($db, $query);
  
//     if(mysqli_num_rows($result) > 0) {
//       // if the number is already in the database, generate a new one
//       $newNumber=generateUniqueNumber($db);
//       return $newNumber;
//     } else {
//       // if the number is not in the database, store it and return it
//       $query = "INSERT INTO verification (code) VALUES ('$newNumber')";
//       mysqli_query($db, $query);
//       return $newNumber;
//     }
//   }
  
//   // example usage
//   $db = mysqli_connect('localhost', 'root', '', 'project');
//   $uniqueNumber = generateUniqueNumber($db);
//   echo $uniqueNumber;
?>