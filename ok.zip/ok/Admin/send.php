<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">
        <title>Send</title>
        <link href="../style.css" rel="stylesheet" type="text/css" />
<link href="../beauty.css" rel="stylesheet" type="text/css" />

</head>
<style>
.form-group {
  margin-bottom: 1rem;
}
.form-control {
  display: block;
  width: 85%;
  padding: 0.5rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;

  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.form-control:focus {
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.btn {
  display: inline-block;
  font-weight: 400;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  user-select: none;
  border: 1px solid transparent;
  padding: 0.5rem 1rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: all 0.15s ease-in-out;
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
.btn:hover {
  color: #fff;
  background-color: #0069d9;
  border-color: #0062cc;
}
.btn:focus {
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.btn:active {
  color: #fff;
  background-color: #0062cc;
  border-color: #005cbf;
}
.Container {
  width: 60%;
  height: 45vh;
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
  
}

.mt-4 {
  margin-top: 8.5rem !important;
}

.row {
  display: flex;
  flex-wrap: wrap;
  margin-right: -15px;
  margin-left: -15px;
  
}

.justify-content-center {
  -ms-flex-pack: center !important;
  justify-content: center !important;
}

.col-md-8 {
  flex: 0 0 66.666667%;
  max-width: 66.666667%;
}

.card {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  word-wrap: break-word;
  /* background-color: #fff; */
  background-clip: border-box;
  /* border: 1px solid rgba(0,0,0,.125);
  border-radius: .25rem;
  border: 0;
  border-radius: .25rem;
  box-shadow: 0 0.25rem 1rem rgba(0, 0, 0, 0.05); */
  
  background-color: #fff;
  border-radius: 0.75rem;
  border: 1px solid rgba(0, 0, 0, 0.125);
  box-shadow: 0px 0px 10px rgba(52, 58, 64, 0.5);
height: 60vh;

}

.card-body {
  min-height: 1px;
  padding: 1.25rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.mb-4 {
  margin-bottom: 1.5rem !important;
  display: flex;
  align-items: center;
  justify-content: center;
  text-transform: capitalize;
}
h3 {
  font-size: 1.75rem;
  font-weight: 500;
  line-height: 2.5rem;
  margin-bottom: 1rem;
  color: rgba(52, 58, 64, 0.5);
}

label {
  display: inline-block;
  margin-bottom: 0.5rem;
  font-weight: 1000;
  color: rgba(52, 58, 64, 0.5);

}

.alert {
  position: relative;
  padding: 0.75rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid transparent;
  border-radius: 0.25rem;
}

.alert-success {
  color: #155724;
  background-color: #d4edda;
  border-color: #c3e6cb;
}

.alert-danger {
  color: #721c24;
  background-color: #f8d7da;
  border-color: #f5c6cb;
}

.alert-success .close,
.alert-danger .close {
  position: absolute;
  top: 0;
  right: 0;
  padding: 0.75rem 1.25rem;
  color: inherit;
}

.btn-close {
  box-sizing: content-box;
  width: 1em;
  height: 1em;
  padding: 0.25em 0.25em;
  color: #000;
  background-color: #fff;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  opacity: 0.5;
  transition: opacity 0.15s ease-in-out;
}

.btn-close:hover {
  color: #000;
  text-decoration: none;
  opacity: 0.75;
}

.btn-close:focus {
  outline: 0;
  box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
  opacity: 1;
}

</style>
  
<body style="background-color: rgba(0,150,170,0.05);" >
<script>
  function remo(){
    var url = window.location.href;

// Remove the query parameters
url = url.split("?")[0];

// Modify the current URL without reloading the page
history.replaceState(null, null, url);
// Get all alert elements
const alertElements = document.querySelectorAll('.alert');

// Loop through each alert element
alertElements.forEach(alert => {
  // Add event listener to close button
  alert.querySelector('.btn-close').addEventListener('click', () => {
    // Hide the alert element
    alert.classList.add('d-none');
    // Remove the alert element from the DOM after a delay of 500ms
    setTimeout(() => {
      alert.remove();
    }, 500);
  });
});

  }
// Get the current URL


</script>
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="../index.php" >Home</a></li>
            <li><a href="../contact.php">Contact</a></li>
            <li><a href="../about.php">About</a></li>
            <li><a href="../customerannouncement.php">Announcment</a></li>
            <li><a href="../services.php">Services</a></li>
            <li><a href="../adminlog.php">Login</a></li>
            <li><a href="send.php" id="send">Pay</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <div class="Container mt-4 ">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-body">
    <div class="form" id="ffro">
    <div class="row">
  <div class="col-sm-6">  
    <!-- Success Message -->  
    <?php   
    $msg = '';
    if(isset($_GET['action']) && $_GET['action'] == 'succ' && isset($_GET['msg'])) {
        $msg = strval($_GET['msg']);
    }
    if($msg){ ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Well done!</strong> <?php echo htmlentities($msg);?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" onclick="return remo();" aria-label="Close">&times;</button>
      </div>
    <?php } ?>

    <!-- Error Message -->
    <?php 
    $error = '';
    if(isset($_GET['action']) && $_GET['action'] == 'err' && isset($_GET['error'])) {
        $error = strval($_GET['error']);
    }
    if($error){ ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Oh snap!</strong> <?php echo htmlentities($error);?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" onclick="return remo();" aria-label="Close">&times;</button>
      </div>
    <?php } ?>
  </div>
</div>

<form method="post" id="form" action="backend.php">
  <div class="form-group">
  <h3 class="mb-4">Send payment info</h3>
    <label for="name">Code:</label>
    <input type="text" class="form-control" id="name" name="name" placeholder=" your Identification code"required>
  </div>
  <div class="form-group">
    <label for="email">Transaction No:</label>
    <input type="text" class="form-control" id="txn" name="txn" placeholder="valid transaction number" required>
  </div>
  <button type="submit" class="btn btn-primary" >Submit</button>
</form>

</div>
</div>
</div>
</div>
</div>
</div>
<script>
const id = document.getElementById("name");
const tt = document.getElementById("txn");
const form = document.getElementById("form");

id.addEventListener('input', () => {
  if (!isid()) {
    id.setCustomValidity('Please enter a valid Identification code.');
  } else {
    id.setCustomValidity('');
  }
});

tt.addEventListener('input', () => {
  if (!istt()) {
    tt.setCustomValidity(`Please enter a valid Transaction Number.`);
  } else {
    tt.setCustomValidity('');
  }
});

function isid() {
  const name = id.value.trim();
  return /^[a-zA-Z0-9]{12}$/i.test(name);
}


function istt() {
  const name = tt.value.trim();
  return /^[a-zA-Z0-9]+$/.test(name);
}

form.addEventListener('submit', (event) => {
  if (!form.checkValidity()) {
    event.preventDefault();
  }
});

</script>

<!-- JS files -->
<script src="../beauty.js"></script>
<footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>
</body>
</html>