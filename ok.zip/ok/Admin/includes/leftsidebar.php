<div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
             j           <ul>
                        	<li class="menu-title">Navigation</li>

                            <li class="list-unstyled">
                                <a href="../index.php" class="waves-effect"><i class="mdi mdi-home"></i><span> Home </span></a>
                            </li>
                            <li class="has_sub">
                                <a href="./dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-calendar-clock"></i><span>Schedule </span> <span class="menu-arrow"></span></a>
                                    <ul class="for news">
                            <li class="has_sub">
                                <a href="./dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>
                            <li class="list-unstyled">
                                <a href="schedulform.php" class="waves-effect"><i class="mdi mdi-calendar-plus"></i><span> Add Schedule </span></a>
                            </li>

                            <li class="list-unstyled">
                                <a href="./ManageSchedule.php" class="waves-effect"><i class="mdi mdi-calendar-edit"></i> <span>Manage</span></a>
                            </li>            
      
        </li></ul>



                            
                            
        
        
        <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Announcement </span> &nbsp;&nbsp;&nbsp;<span class="menu-arrow"></span></a>
                                    <ul class="for Announcement">
                            <li class="has_sub">
                                <a href="./Announcement/announcement-dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>             
  <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Announcement </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="./addAnnouncment.php"><i class="mdi mdi-plus"></i>Add Announcement</a></li>
                                    <li><a href="./ManegAnnouncment.php"><i class="mdi mdi-pencil"></i>Manage Announcement</a></li>
                                     <li><a href="./trashAnnouncemnt.php"><i class="mdi mdi-delete"></i>Trash Announcement</a></li>
                                </ul>
                            </li>  
  
        </li></ul>
   
        <li class="has_sub">
                                <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Accept </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="./requestAcceptone.php"><i class="mdi mdi-account-check"></i> Request</a></li>
                                </ul>
                            </li></li>
                            <li class="has_sub">
                                <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Status </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="./checkedList.php"><i class="mdi mdi-check-circle"></i>Checked List</a></li>
                                    <li><a href="./cancelledList.php"><i class="mdi mdi-cancel"></i>Cancelled List</a></li>
                                </ul>
                            </li></li>





                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    

                </div>
                <!-- Sidebar -left -->

</div>