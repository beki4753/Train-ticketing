<?php
session_start();
include('./includes/config.php');
error_reporting(0);

if(strlen($_SESSION['login'])==0)
  { 
header('location: ./index.php');
}else{
  if($_GET['action']='del')
{
$postid=intval($_GET['pid']);
$query=mysqli_query($con2,"delete from schedule where id='$postid'");
if($query)
{
$msg="Schedule deleted ";
}
else{
$error="Something went wrong . Please try again.";    
} 
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App favicon -->
        <link rel="shortcut icon" href="./assets/images/favicon.ico">
        <!-- App title -->
        <title>Admin | Manage Schedule</title>

        <!--Morris Chart CSS -->
		<link rel="stylesheet" href="./plugins/morris/morris.css">

        <!-- jvectormap -->
        <link href="./plugins/jvectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

        <!-- App css -->
        <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css">

<link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/core.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/components.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/pages.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/menu.css" rel="stylesheet" type="text/css" />
<link href="./assets/css/responsive.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="./plugins/switchery/switchery.min.css">
<script src="./assets/js/modernizr.min.js"></script>

    </head>


    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
           <?php include('./includes/topheader.php');?>

            <!-- ========== Left Sidebar Start ========== -->
           <?php include('./includes/leftsidebar.php');?>


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                                        
                  
                    <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Manage Schedule </h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Admin</a>
                                        </li>
                                        <li>
                                            <a href="#">Schedules</a>
                                        </li>
                                        <li class="active">
                                        Manage Schedule 
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->
                        <div class="row">
<div class="col-sm-6">  
<!---Success Message--->  
<?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo htmlentities($msg);?>
</div>
<?php } ?>

<!---Error Message--->
<?php if($error){ ?>
<div class="alert alert-danger" role="alert">
<strong>Oh snap!</strong> <?php echo htmlentities($error);?></div>
<?php } ?>


</div>
</div>
                        <div class="col-md-12">
  <div class="container mt-4">
    <form id="MyForm" action="" method="post" role="Form">
      <div class="row">
          <fieldset style="border: 1px">
            <div class="row">
                
              <div class="col-sm-6 col-md-6">
                <div class="form-group">
                  <label class="control-label">Request_Id</label>
                  <div class="input-group">
                    <input id="text" name="id" type="text" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-6">
                <div class="form-group">
                  <label class="control-label">Date</label>
                  <div class="input-group">
                    <input id="date" name="datee" type="date" class="form-control">
                  </div>
                </div>
              </div>

<div class="col-sm-6 col-md-6">
  <div class="form-group">
    <label class="control-label">&nbsp;</label>
    <div class="input-group">
    <button type="submit" onclick="test()" name="submit"class="btn btn-success margin-btn-sm">
          <i class="mdi mdi-check-circle"></i> Show
        </button>

    </div>
  </div>
</div>
</form>

<!-- Table start -->
<div class="row">
  <div class="col-sm-12">
    <div class="card-box">
      <div class="table-responsive">
        <table class="table table-colored table-centered table-inverse m-0">
          <thead>
            <tr>
            <th>Request_Id</th>
        <th>Name</th>
        <th>Phone</th>
        <th>Status</th>
        <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
  if (isset($_POST['id']) && isset($_POST['datee'])) {
    $query2 = "SELECT request.Request_Id, request.name, request.phone, checked.date, checked.status
    FROM request
    JOIN checked ON request.Request_Id = checked.Request_Id
    WHERE  request.Request_Id= ? AND checked.status = 'cancelled' AND checked.date= ?   ";
$stmt = $con2->prepare($query2);
$stmt->bind_param("ss",  $_POST['id'],$_POST['datee']);
$stmt->execute();
$result = $stmt->get_result();

   
     if ($result->num_rows==0) {
            ?>
                <tr>
                  <td colspan="4" align="center">
                    <h3 style="color:red">No record found</h3>
                  </td>
                </tr>
              <?php 
              } else {
                while ($row2 = mysqli_fetch_assoc($result)) {
              ?>
                  <tr>
                  <td><b><?php echo htmlentities($row2['Request_Id']);?></b></td>
        <td><?php echo htmlentities($row2['name'])?></td>
        <td><?php echo htmlentities($row2['phone'])?></td>
        <td><?php echo htmlentities($row2['status'])?></td>
        <td><?php echo htmlentities($row2['date'])?></td>
                   </tr>
<?php } }   }
}else{  
  $system_date = date('Y-m-d');
  $query=mysqli_query($con2," SELECT request.Request_Id, request.name, request.phone, checked.date, checked.status
  FROM request
  JOIN checked ON request.Request_Id = checked.Request_Id
  WHERE  checked.date like '%$system_date%' AND checked.status = 'cancelled'");
  $rowcount=mysqli_num_rows($query);
  if($rowcount==0 ) {
?>
    <tr>
      <td colspan="4" align="center">
        <h3 style="color:red">No record found</h3>
      </td>
    </tr>
  <?php 
  } else {
    while($row=mysqli_fetch_array($query)) {
  ?>
      <tr>
        <td><b><?php echo htmlentities($row['Request_Id']);?></b></td>
        <td><?php echo htmlentities($row['name'])?></td>
        <td><?php echo htmlentities($row['phone'])?></td>
        <td><?php echo htmlentities($row['status'])?></td>
        <td><?php echo htmlentities($row['date'])?></td>
</tr>
<?php } }}?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



                    </div> <!-- container -->

                </div> <!-- content -->

       <?php include('../includes/footer.php');?>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

<script src="./assets/js/jquery.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script src="./assets/js/detect.js"></script>
        <script src="./assets/js/fastclick.js"></script>
        <script src="./assets/js/jquery.blockUI.js"></script>
        <script src="./assets/js/waves.js"></script>
        <script src="./assets/js/jquery.slimscroll.js"></script>
        <script src="./assets/js/jquery.scrollTo.min.js"></script>
        <script src="./plugins/switchery/switchery.min.js"></script>

        <!-- Counter js  -->
        <script src="./plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="./plugins/counterup/jquery.counterup.min.js"></script>

        <!--Morris Chart-->
		<script src="./plugins/morris/morris.min.js"></script>
		<script src="./plugins/raphael/raphael-min.js"></script>

        <!-- Dashboard init -->
        <script src="./assets/pages/jquery.dashboard.js"></script>

        <!-- App js -->
        <script src="./assets/js/jquery.core.js"></script>
        <script src="./assets/js/jquery.app.js"></script>

    </body>
</html>
<?php } ?>