<?php
session_start();

include('./includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
    if($_GET['action']='rest')
    {
    $postid=intval($_GET['pid']);
    $query=mysqli_query($con2,"update images set Is_Active=1 where id='$postid'");
    if($query)
    {
    $msg="Post deleted ";
    }
    else{
    $error="Something went wrong . Please try again.";    
    } 
    }
    else if($_GET['action']='del'){
    $postid=intval($_GET['pid']);
    $query=mysqli_query($con2,"delete from images where id='$postid'");
    if($query)
    {
    $msg="Post Restored ";
    }
    else{
    $error="Something went wrong . Please try again.";    
    }    
    }
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">
        <!-- App title -->
        <title>Admin | Dashboard</title>
       <!-- App favicon -->
       <link rel="shortcut icon" href="./assets/images/favicon.ico">
        <!-- App title -->
        <title>DU Radio | Add Post</title>

        <!-- Summernote css -->
        <link href="./plugins/summernote/summernote.css" rel="stylesheet" />

        <!-- Select2 -->
        <link href="./plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />

        <!-- Jquery filer css -->
        <link href="./plugins/jquery.filer/css/jquery.filer.css" rel="stylesheet" />
        <link href="./plugins/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet" />

        <!-- App css -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>

        <link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="./assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="./plugins/switchery/switchery.min.css">
        <script src="./assets/js/modernizr.min.js"></script>
<style>
.img-fluid{
    width: 50vw;
    height: 70vh;
    display: block;
    border: 1px solid rgba(0,0,0,0.1);
}
.row{
    display: flex;
    flex-wrap:wrap;
    /* align-items: center;
    justify-content: center; */
}
.lead{
    display: flex;
    flex-wrap: wrap;
    float: left;
}
.col-md-6{
    display: block;
    position: relative;
    margin-left: 15vw;
}
@media screen and (max-width: 600px){
    .col-md-6{
    margin-left: auto;
}
.img-fluid{
    width: 90vw;
    height: 70vh;
}
}
</style>
    </head>


    <body class="fixed-left">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.html" class="logo"><span>NP<span>Admin</span></span><i class="mdi mdi-layers"></i></a>
                    <!-- Image logo -->
                    <!--<a href="index.html" class="logo">-->
                        <!--<span>-->
                            <!--<img src="./assets/images/logo.png" alt="" height="30">-->
                        <!--</span>-->
                        <!--<i>-->
                            <!--<img src="../assets/images/logo_sm.png" alt="" height="28">-->
                        <!--</i>-->
                    <!--</a>-->
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
            <?php include('./includes/topheader.php');?>
            </div>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->
    <?php include('./includes/leftsidebar.php');?>
            <!-- Left Sidebar End -->



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                    <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Trash Announcement</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Admin</a>
                                        </li>
                                        <li>
                                            <a href="#">Announcement</a>
                                        </li>
                                        <li class="active">
                                        Trash Announcement 
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <div class="row">
        

                        <!-- <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Are you sure you want to delete this?</strong>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div> -->


<div class="col-sm-6">  
<!---Success Message--->  
<?php if($msg){ ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>Well done!</strong> <?php echo htmlentities($msg);?>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>

<!---Error Message--->
<?php if($error){ ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
<strong>Oh snap!</strong> <?php echo htmlentities($error);?></div>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
<?php } ?>


</div>
</div>
        <?php 
$db = mysqli_connect("localhost", "root", "", "project");
$sql = "SELECT images.id as postid, images.image as photo, images.text as meglecha FROM images where images.Is_Active=0";
$result = mysqli_query($db, $sql);
while ($row = mysqli_fetch_array($result)){
    echo "<div class='row mb-5'>";
        echo "<div class='col-md-6'>";
            echo "<img src='./images/".$row['photo']. "' class='img-fluid' alt='Announcement Image'>";
       echo "</div>"; 
        echo "<div class='col-md-6'>";
            echo "<p class='lead'>".$row['meglecha']. "</p>";
        echo "</div>";
  ?>
<a href="trashAnnouncemnt.php?pid=<?php echo htmlentities($row['postid']);?>&&action=del" onclick="return confirm('This action can not be restored!\nDo you reaaly want to delete ?')"> <i class="fa fa-trash-o" style="color: #f05050"></i></a>;
&nbsp;<a href="trashAnnouncemnt.php?pid=<?php echo htmlentities($row['postid']);?>&&action=rest" onclick="return confirm('Do you reaaly want to Restore it ?')"> <i class="fa fa-trash-restore" style="color: #f05050"></i></a>;

  <?php

    echo "</div>";
}

   
        

    ?>
                    </div> <!-- container -->

                </div> <!-- content -->


            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


 

        </div>
        <!-- END wrapper -->



        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="./assets/js/jquery.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
        <script src="./assets/js/detect.js"></script>
        <script src="./assets/js/fastclick.js"></script>
        <script src="./assets/js/jquery.blockUI.js"></script>
        <script src="./assets/js/waves.js"></script>
        <script src="./assets/js/jquery.slimscroll.js"></script>
        <script src="./assets/js/jquery.scrollTo.min.js"></script>
        <script src="./plugins/switchery/switchery.min.js"></script>

        <!--Summernote js-->
        <script src="./plugins/summernote/summernote.min.js"></script>
        <!-- Select 2 -->
        <script src="./plugins/select2/js/select2.min.js"></script>
        <!-- Jquery filer js -->
        <script src="./plugins/jquery.filer/js/jquery.filer.min.js"></script>

        <!-- page specific js -->
        <script src="./assets/pages/jquery.blog-add.init.js"></script>

        <!-- App js -->
        <script src="./assets/js/jquery.core.js"></script>
        <script src="./assets/js/jquery.app.js"></script>

        <script>

            jQuery(document).ready(function(){

                $('.summernote').summernote({
                    height: 240,                 // set editor height
                    minHeight: null,             // set minimum height of editor
                    maxHeight: null,             // set maximum height of editor
                    focus: false                 // set focus to editable area after initializing summernote
                });
                // Select2
                $(".select2").select2();

                $(".select2-limiting").select2({
                    maximumSelectionLength: 2
                });
            });
        </script>
  <script src="./plugins/switchery/switchery.min.js"></script>

        <!--Summernote js-->
        <script src="./plugins/summernote/summernote.min.js"></script>
    </body>
</html>
<?php } ?>