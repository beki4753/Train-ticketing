
<?php

// function generateUniqueNumber($db) {
//     $newNumber = strval(mt_rand(100000000000, 999999999999));
//     $query = "SELECT Ticket_Id FROM ticket WHERE Ticket_Id = '$newNumber'";
//     $result = mysqli_query($db, $query);
  
//     if(mysqli_num_rows($result) > 0) {
//         // if the number is already in the database, generate a new one
//         $newNumber = generateUniqueNumber($db);
//     }
    
//     return $newNumber;
// }

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";
$conn = new mysqli($servername, $username, $password, $dbname);

if($_GET['action']='cancel') {
    $postid = intval(base64_decode($_GET['pid']));  
    
    $db = mysqli_connect('localhost', 'root', '', 'project');
  
    
    // SELECT request information
    $request_sql = "SELECT Request_Id,phone,date,num_person,source,destination FROM request WHERE Request_Id='$postid'";
    $request_result = $conn->query($request_sql);
    
    if($request_result->num_rows > 0) {
        while($row = $request_result->fetch_assoc()) {
            $request_id = $row['Request_Id'];
            $phone = $row['phone'];
            $date = $row['date'];
            $num_person = $row['num_person'];
            $source = $row['source'];
            $destination = $row['destination'];

                            $checked_sql = "select * from `checked` where date='$date' and status='cancelled' and Request_Id='$request_id'";
                            $checked_result = $conn->query($checked_sql);
                            if($checked_result->num_rows>0){
                                $err="User alredy cancelled.";
                            }else{
                                $checked_sql = "INSERT INTO `checked`(`date`,`status`,`Request_Id`) 
                                VALUES ('$date','cancelled','$request_id')";
                                $checked_result = $conn->query($checked_sql);
                                if($checked_result) {
                                // INSERT ticket information
                                $ticket_sql = "select * from `ticket` where `Ticket_Id`='$newNumber' and `origin`='$source' and `destination`='$destination' and `date`='$date' and `time`='$time' and `person`='$num_person' and `Request_Id`='$request_id' and `Train_id`='$train_id'";
                                $ticket_result = $conn->query($ticket_sql);
                                if($ticket_result->num_rows>0){
                                    $err="Ticket exist.";
                                }else{
                                        $msg="user Canceled!";
      
                            }

                        }
                    }
                }
            
        
    } else {
        $err= "No request found";
    }

    if(strlen($err)>0){
        header("Location: requestAcceptone.php?error=$err && action=err");
        }else if(strlen($msg)>0){
        header("Location: requestAcceptone.php?msg=$msg && action=succ");
    }


}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>