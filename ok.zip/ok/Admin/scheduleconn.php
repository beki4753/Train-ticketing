<?php

$fromm = $_POST['source'];
$too = $_POST['destination'];
$time = $_POST['time'];
$datee = $_POST['datee'];
echo '<script>';
echo 'alert("$time");';
echo '</script>';
$Itime = new DateTime($time, new DateTimeZone("Africa/Addis_Ababa"));
$Ethiopian_time = $Itime->format("h:i A");
var_dump($Ethiopian_time);

//database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die('Connection Failed : ' . $conn->connect_error);
} else {
    try {
        $stmt = $conn->prepare("INSERT INTO schedule (source, destination, date, time) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fromm, $too, $datee, $Ethiopian_time);
        if ($stmt->execute()) {
            echo '<script>';
            echo 'alert("Inserted successfully...");';
            echo '</script>';
        } else {
            echo '<script>';
            echo 'alert("Insertion failed...");';
            echo '</script>';
        }
        $stmt->close();
        $conn->close();
        header("Location: schedulform.php");
    } catch (Exception $e) {
        echo '<script>';
        echo 'alert("Message"'.$e->getMessage().');';
        echo '</script>';
        header("Location: schedulform.php");
    }
}

?>
