<?php

// require_once("conn.php");
if(isset($_POST['update']))
    {

        $UserID = $_GET['datee'];
        $UserName = $_POST['source'];
        $UserEmail = $_POST['destination'];
        $UserAge = $_POST['time'];
         

  $dbhost = 'localhost';
  $dbuser = 'root';
  $dbpass = '';
  $connec = MySQL_connect($dbhost, $dbuser, $dbpass);
  if(!$connec)
  {
  die('Could not connect: ' . MySQL_error());
  }
  $sql = "UPDATE schedule
  SET source ='$UserName' destination='$UserEmail' time='$UserAge'
  WHERE date='$UserID'";
  MySQL_select_db('project');
  $result = MySQL_query($sql, $connec);
  if(!$result)
  {
  die('Could not update data: ' . MySQL_error());
  }
  echo "Data successfully updated...";
  MySQL_close($connec);
}
?>