<?php
$username =$_POST['username'];
$password =$_POST['password'];

//database connection
$conn = new mysqli('localhost','root','','project');
if($conn->connect_error){
	die('Connection Failed : '.$conn->connect_error);//making unique email and password not to duplicate
}
?>