<!-- <!DOCTYPE html>
<html>
<head>
	    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
</head>
<body>
	<form action="scheduleconn.php" method="post">

		<label >Origin</label>
         <select name="source" id="s">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select><br><br>
		<label >     Destination</label>
         <select name="destination" id="d">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select><br><br>
		<input type="time" name="time" placeholder="Time" required=""><br><br>
		<input type="date" name="datee"><br><br>
		<input type="reset" name="reset" value="reset">
		<input type="submit" name="insert" onclick="abc()">
        <script type="text/javascript">

            function abc(){
                selectElement=document.querySelector('#s');
                var a=selectElement.value;
                selectElement=document.querySelector('#d');
            var b=selectElement.value;
            
           
                            if (a === b) {
                 window.alert("Incorrect selection Select correctly!!");
                 window.location.replace("updateschedule.php");
            }
            }
            

        </script>
	</form>

</body>
</html>
 -->


<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
    .togler{
  display: none;
  background:#35424a;
  padding: 0px;
  align-items: center;
  /* border: 1px solid black; */
}
.togler img{
width: 30px;
height: 30px;

}

.show{
  display: block;
  background:#35424a;
  color:#ffffff;
  padding-top:30px;
  z-index: 999;
  justify-content: flex-start;
align-items: center;
float: center;
}
.show li{
  float: left;
  justify-content: flex-start;
align-items: center;
  display: flex;
  flex-wrap:wrap;
  flex-basis: auto;
}
        @media screen and (max-width: 904px) {
          .button_1{
               
                display: flex;
                align-items: center;
                /* flex-wrap: wrap; */
                height:20px;
padding-left: 50px;

  width: 110px;
  background:#e8491d;
  border:1px solid black;
  padding: 10px;
  color:#ffffff;
  text-decoration: none;
 text-align: center;
 margin: auto;
}

        .navbar:not(.show){
            display: none;
        }
        .title{
          width: 10vw;
          margin-left: -0.3vw;
        }
        .show{
          display: -ms-flexbox !important;
    display: flex !important;
    -ms-flex-preferred-size: auto;
    flex-basis: auto;
        }
.togler{
  display: block;
width: 2rem;
height: 2rem;
margin-left: 65vw;
align-items: center;
}

    }
    #newsletter{
      display: flex;
      flex-wrap: wrap;
    }
    @media screen and (max-width:319px){
      .navbar:not(.show) {
            display: none;
        }
      .title h1{
          display: flex;
          flex-wrap: wrap;
        }
        .togler{
  display: block;
}
.show{
          display: -ms-flexbox !important;
    display: flex !important;
    -ms-flex-preferred-size: auto;
    flex-basis: auto;
        }          .button_1{
               
               display: flex;
               align-items: center;
               /* flex-wrap: wrap; */
               height:20px;
 width: 110px;
 background:#e8491d;
 border:1px solid black;
 padding: 10px;
 color:#ffffff;
 text-decoration: none;
text-align: center;
margin: auto;
}

    }
    .navbar {
transition: background-color 0.5s ease-in-out;
}

.navbar-scrolled {
background-color: rgba(52, 58, 64, 0.3) !important;

}
    </style>
    
</head>
<body >

<header>
<div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <button  class="togler "><img src="togler.png"/></button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="login.php">Login</a></li>
          </ul>
        </nav>
    
    </header>
	
		<div class="ay">
        <form action="scheduleconn.php" method="post">

<label >Origin</label>
 <select name="source" id="s">
    <option value="Adama">Adama</option>
    <option value="Meiso">Meiso</option>
    <option value="Dire Dawa">Dire Dawa</option>
    <option >Alisabeh</option>
    <option >Nagada</option>
</select><br><br>
<label >     Destination</label>
 <select name="destination" id="d">
    <option value="Adama">Adama</option>
    <option value="Meiso">Meiso</option>
    <option value="Dire Dawa">Dire Dawa</option>
    <option >Alisabeh</option>
    <option >Nagada</option>
</select><br><br>
<input type="time" name="time" placeholder="Time" required=""><br><br>
<input type="date" name="datee" required><br><br>
		<input type="reset" name="reset" value="reset" class="sub2">
		<input type="submit" name="insert" onclick="abc()" class="sub">
        <script type="text/javascript">

            function abc(){
                selectElement=document.querySelector('#s');
                var a=selectElement.value;
                selectElement=document.querySelector('#d');
            var b=selectElement.value;
            
           
                            if (a === b) {
                 window.alert("Incorrect selection Select correctly!!");
                 window.location.replace("schedulform.php");
            }
            }
            

        </script>
	</form>
        </div>
        </div>		
        <script>
document.querySelector('.togler').addEventListener('click', function(){
this.checked= !this.checked;
var navbar = document.querySelector('.navbar');
if(navbar.classList.contains('show')){
  navbar.classList.remove('show');
}
 else {
  navbar.classList.add('show');
 
}
});
window.addEventListener('scroll',function() {
    
    var navbar = document.querySelector('.navbar');
if (window.scrollY > 20) {
navbar.classList.add('navbar-scrolled');

} else {
  navbar.classList.remove('navbar-scrolled');
 
}
});
</script>
</body>
</html>
