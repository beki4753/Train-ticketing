<?php 
    $msg = "";
    if (isset($_POST['upload'])){
        

        $target = "images/".basename($_FILES['image']['name']);



         $db = mysqli_connect("localhost", "root", "", "project");

         $image = $_FILES['image']['name'];
         $text = $_POST['text'];

         $sql = "INSERT INTO images (image, text) VALUES ('$image', '$text')";
         mysqli_query($db, $sql);

        //  if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        //      $msg = "Image Uploaded successfully";
        //  }else{
        //      $msg = "there was a problem uploading image";
        //  }
    }

       
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image upload</title>
   <link rel="stylesheet" type="text/css" href="style.css">
   <link rel="stylesheet" type="text/css" href="adminannouncment.css">
   <style>
   @media screen and (max-width: 768px){
    .imgbut{
      width:95vw !important;
  margin:auto !important;
  overflow:hidden !important;

    }
    .imgbut img{
      width: 95vw;
height: 90vh;
    }
   }
   .sub{
	padding: 8px;
	border-radius: 5px;
	font-weight: bold;
	font-family: verdana;
	background-color: #0E4c92;
	color: white;
}
   </style>
</head>
<body>

  <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>

            <li><a href="Admin.php">GO Back</a></li>

          </ul>
        </nav>
      </div>
    </header>

      <div id="content" >

    <?php 
        
        $db = mysqli_connect("localhost", "root", "", "project");
        $sql = "SELECT * FROM images";
        $result = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_array($result)){
            echo "<div id='img_div' class='imgbut'>";
                echo "<img src='images/".$row['image']. "'>";
                echo "<p style='font-size: 20px; font-family: Time New Roman;'>".$row['text']. "</p>";
            echo "</div>";

        }

    ?>

<form action="" method="POST" enctype="multipart/form-data" class="form">
  <div class="mb-3">
    <input type="hidden" name="size" value="1000000">
  </div>
  <div class="mb-3">
    <label for="image" class="form-label">Choose Image</label>
    <input type="file" name="image" class="form-control" id="image">
  </div>
  <div class="mb-3">
    <label for="text" class="form-label">Say something about this...</label>
    <textarea name="text" cols="40" rows="4" class="form-control" id="text"></textarea>
  </div>
  <div class="mb-3">
    <button type="submit" name="upload" class="btn btn-primary">Upload Image</button>
  </div>
</form>



          <footer>
            <p >
               Train Ticketing, Copyright &copy; 2022 
            </p>
    </footer>
</body>
</html>