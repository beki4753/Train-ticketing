
document.querySelector('.togler').addEventListener('click', function(){
    this.checked= !this.checked;
    var navbar = document.querySelector('.navbar');
    if(navbar.classList.contains('show')){
      navbar.classList.remove('show');
    
    }
     else {
      navbar.classList.add('show');
    
     
    }
    });
    window.addEventListener('scroll',function() {
        
      var navbar = document.querySelector('header');
      var butts = document.getElementById('navbar-toggle');
    if (window.scrollY > 20) {
    navbar.classList.add('navbar-scrolled');
    butts.classList.add('navbar-scrolled');
    } else {
      navbar.classList.remove('navbar-scrolled');
      butts.classList.remove('navbar-scrolled');
      
     
    }
    });
    function checkwindowsize(){
      var navbar = document.querySelector('.navbar');
    var element = document.querySelector('.togler');
    var computedStyle =window.getComputedStyle(element);
    if(window.innerWidth>=904){
    
    
      if(computedStyle.display === 'none'){
        navbar.classList.remove('show');
      }
    }
    }
    window.addEventListener('resize', checkwindowsize);

    var currentUrl= window.location.href;
    var links = document.querySelectorAll('header a');
    for( var i=0; i<links.length; i++){
      var link = links[i];
      if(link.href === currentUrl){
        link.classList.add('active');
      }
    }
    