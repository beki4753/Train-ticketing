const fname = document.getElementById('fname');
const lname= document.getElementById('lname');
const email = document.getElementById('email');
const phone = document.getElementById('phone');
const password = document.getElementById('password');
const address = document.getElementById('address');
const form = document.getElementById('form');
const errorElement = document.getElementById('error')

const setError = (element, message) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');
    
    errorDisplay.innerText = message;
    errorDisplay.style.color = "red";
    inputControl.classList.add('error');
    inputControl.classList.remove('success');
    }

const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');
    errorDisplay.innerText = '';
  
    inputControl.classList.add('success');
inputControl.classList.remove('error');
};

const isValidEmail = email => {
    const re = varpattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 
    return re.test(String(email).toLowerCase());
}
function validatePhoneNumber(input_str) 
{
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

    return re.test(input_str);
}

form.addEventListener('submit',(e) => { 
    let messages = []
    if (fname.value === '' || fname.value == null) {
        messages.push('first name is required')
    }
    if (lname.value === '' || lname.value == null) {
        messages.push('last name is required')
    }
    if (email.value === '' || email.value == null) {
        messages.push('email is required')
    }
  

    if (phone.value === '' || phone.value == null) {
        messages.push('phone is required')
    }
    else if(phone.value.length < 10) {
        messages.push('enter correct 10 digit number')
    }
    else if(phone.value.length > 10) {
        messages.push('enter correct 10 digit number')
    }
  else if(!validatePhoneNumber(phone.value)) {
    messages.push('enter only a number')
  } else {
    setSuccess(phone);
  }
   
    if (address.value === '' || address.value == null) {
        messages.push('address is required')
    }
    if(address.value.length >= 20) {
        messages.push('enter your city name')
    }
   
    
    
    if(password.value.length <= 6) {
        messages.push('password must be 6 characters or longer than 6 characters')
    }
    if(password.value.length >= 10) {
        messages.push('password must be 10 characters or shorter than 10 characters')
    }

    if (messages.length > 0){
    e.preventDefault();
    errorElement.innerText = window.alert(messages.join(', ')
    errorElement.style.color = "red";
 }

})