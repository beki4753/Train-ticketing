<?php

// Connect t o database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve form data
    $name = $_POST['Name'];
    $phone = $_POST['Phone'];
    $Id = $_POST['idd'];
    $Date = $_POST['Date'];
    $num = $_POST['num'];
    $origin = $_POST['origin'];
    $destination = $_POST['destination'];


    // Validate form data
    if (empty($name) || empty($phone) || empty($Id) || empty($Date) || empty($num) || empty($origin) || empty($destination)) {

        echo '<script type="text/javascript">';
        echo 'window.alert("Please fill all the fields");';
        echo 'window.location.href = "reservation.php";';
        echo '</script>';
    }else {
date_default_timezone_set('Africa/Addis_Ababa');
$time = date('h:i'); //user inserted time

$curent = date('y-m-d');// current date

//fetching data based on current date
$sql = "SELECT `time` FROM schedule WHERE date = '$curent' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc() ){
    $scheduletime =  $row['time'];
    }
}
// Assume $datetime_string contains the retrieved datetime string from the database
$datetime = new DateTime($scheduletime);
$datetime->setTimezone(new DateTimeZone('Africa/Addis_Ababa'));
$formatted_datetime = $datetime->format('H:i');

$Difference=$formatted_datetime-$time;

$percent = $Difference*0.3;
$_SESSION['dead']=$percent;
// echo $percent;
            $sql = "INSERT INTO request (name,Request_Id,phone,id,date,time,num_person,source,destination) VALUES('$name','','$phone','$Id','$Date','$percent','$num','$origin','$destination')";
            if ($conn->query($sql) === TRUE) {
                include "paypop.php";
                echo '<script type="text/javascript">';
                echo 'var modal = document.getElementById("myModal");';
                echo 'modal.style.display = "block";';
                echo '</script>';
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }



    while (true) {

      $sql = "SELECT `Request_Id`, `time` FROM `request` WHERE `date` = '$curent'";
      $result = $conn->query($sql);
  
      if ($result->num_rows > 0) {
          $row = $result->fetch_assoc();
          $requestId = $row['Request_Id'];
  
          $sql = "SELECT `Request_Id` FROM `checked` WHERE `date` = '$curent' AND `Request_Id` = '$requestId'";
          $result = $conn->query($sql);
  
          if ($result->num_rows > 0) {
              exit;
          } else {
              $sql = "DELETE FROM `request` WHERE `Request_Id` = '$requestId'";
              $conn->query($sql);
          }
      }
  
      sleep(5);
  }
  
$conn->close();
?>
