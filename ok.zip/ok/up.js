function Valid()
{


var fname = document.hh.fname;
var lname = document.hh.lname;
var uemail = document.hh.email;
var phone = document.hh.phone;
var pass = document.hh.pass;
var uadd = document.hh.address;


if(allLetter(fname))
{
if(allLetter2(lname))
{
if(ValidateEmail(uemail))
{
if(allnumeric(phone))
{
if(passid_validation(pass))
{
if(alphanumeric(uadd))
{

}   
}   
}   
}   
}   
}


return false;

} 


function allLetter(fname)
{ 
var letters = /^[A-Za-z]+$/;
if(fname.value.match(letters))
{
return true;
}
else
{
alert('first name must have alphabet characters only');
fname.focus();
return false;
}
}

function allLetter2(lname)
{ 
var letters = /^[A-Za-z]+$/;
if(lname.value.match(letters))
{
return true;
}
else
{
alert('last name must have alphabet characters only');
lname.focus();
return false;
}
}

function ValidateEmail(uemail)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(uemail.value.match(mailformat))
{
return true;
}
else
{
alert("You have entered an invalid email address!");
uemail.focus();
return false;
}
} 

function allnumeric(phone)
{ 
var numbers = /^[0-9]+$/;
if(phone.value.match(numbers))
{
return true;
}
else
{
alert('Phone code must have numeric characters only');
phone.focus();
return false;
}
}

function passid_validation(passw)
{
var passid_len = pass.value.length;
if (passid_len == 0 ||passid_len >=6 || passid_len < 10)
{
alert("Password should not be empty / length be between 6 to 10");
pass.focus();
return false;
}
return true;
}

function alphanumeric(uadd)
{ 
var letters = /^[0-9a-zA-Z]+$/;
if(uadd.value.match(letters))
{
return true;
}
else
{
alert('User address must have alphanumeric characters only');
uadd.focus();
return false;
}
}






