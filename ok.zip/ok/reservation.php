<?php
session_start();


$sou=$_SESSION['datas'];
$desti=$_SESSION['datad'];
$dat=$_SESSION['date'];


function gregorian_to_ethiopian($dat) {
// Get Gregorian year, month, and day
  list($year, $month, $day) = explode('-', $dat);
  
// Determine if Gregorian year is a leap year
  $is_leap_year = ($year % 4 == 0 && $year % 100 != 0) || ($year % 400 == 0);
  
// Determine Ethiopian offset
  $offset = $is_leap_year ? 1 : 0;
  
// Convert Gregorian date to Ethiopian date
  $ethiopian_year = $year - (($month < 9 || ($month == 9 && $day < 11)) ? 8 : 7);
  $ethiopian_month = ($month - 1 + $offset) % 13 + 1;
  $ethiopian_day = $day + $offset;
  
// Return Ethiopian date in the format Y-M-D
  return sprintf('%04d-%02d-%02d', $ethiopian_year, $ethiopian_month, $ethiopian_day);
}

$ethiopian_date = gregorian_to_ethiopian($dat);


 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation</title>
    <link rel="stylesheet" href="reservation.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="beauty.css">
</head>
<body>
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="adminlog.php">Login</a></li>
            <li><a href="services.php">Services</a></li>
          </ul>
        </nav>
      </div>
    </header>





    <div class="all">
        <div class="header">
    <h1>I want Reserve seat</h1>
    <h3>of a train to travel</h3>
    </div>
    <form  action="" name='registr' id="myform" method="post" >
<br><input id="name" placeholder="e.g Full Name" type="text" name="Name" required><br><br>
        <input id="tel" type="tel" placeholder="Phone Number" maxlength="13" name="Phone" max="10" required><br><br>
        <input id="id" type="id" placeholder="ID Number" name="idd" required><br><br>
        <input id="date" type="date" name="Date" value="<?php echo $ethiopian_date;?>" readonly><br><br>      
        <input type="number" name="num" id="np" min="1"  placeholder="Number of people" required><br><br>
        <label class="org">Origin</label>
        <select name="origin" id="origin" style="width: 70px; "  readonly>
            <option value="<?php echo $sou?>"><?php echo $sou?></option>
        </select>
        <label class="des">Destination</label>
         <select name="destination" id="destination" style="width: 70px; "  readonly>
            <option value="<?php  echo $desti; ?>"><?php  echo $desti; ?></option>
        </select><br><br>
        <input type="reset" name="reset" class="last"><br><br>
        <input type="submit" value="submit" name="submit" class="last"  ><br><br>
    </form>
    </div>
    <div class="foot">
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </div>
    <script type="text/javascript" src="beauty.js"></script>
    <script type="text/javascript" src="form.js"></script>

</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
// $conn = mysqli_connect("localhost", "root", "", "project");

// Check connection
if ($conn->connect_error) {
  echo "<script>alert('Connection failed: $conn->connect_error');</script>";
}


//Start query
//Connect t o database



$sql = "SELECT `time` FROM schedule WHERE source= '$sou' and destination= '$desti' and date = '$dat' ";
$result = $conn->query($sql);
// $result = mysqli_query($conn, $sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc() ){
    $scheduletime =  $row['time'];
    }
}
date_default_timezone_set("Africa/Addis_Ababa");
$disp=date("h:i");
$current_time = strtotime($disp); 

$schedule_time = strtotime($scheduletime); 
$remaining_time = $schedule_time - $current_time; 
$expiry_time = date('Y-m-d H:i:s', $current_time + ($remaining_time * 0.3)); 
$yekerew=($remaining_time * 0.3);
$_SESSION['delete']=date('i:s',$yekerew);


// Check if form is submitted
// $yekerew=0;
$button_status = true;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  if($yekerew===0 || $yekerew<0){
    $button_status=false;
  }

}
if($button_status){
  //  Retrieve form data
    if (isset($_POST['submit'])) {
      $name = filter_input(INPUT_POST, 'Name', FILTER_SANITIZE_STRING);
      $phone = filter_input(INPUT_POST, 'Phone', FILTER_SANITIZE_STRING);
      $Id = filter_input(INPUT_POST, 'idd', FILTER_SANITIZE_STRING);
      $Date = filter_input(INPUT_POST, 'Date', FILTER_SANITIZE_STRING);
      $num = filter_input(INPUT_POST, 'num', FILTER_SANITIZE_STRING);
      $origin = filter_input(INPUT_POST, 'origin', FILTER_SANITIZE_STRING);
      $destination = filter_input(INPUT_POST, 'destination', FILTER_SANITIZE_STRING);
    if (empty($name) || empty($phone) || empty($Id) || empty($Date) || empty($num) || empty($origin) || empty($destination)) {
        echo '<script type="text/javascript">';
        echo 'window.alert("Please fill all the fields");';
        echo 'window.location.href = "reservation.php";';
        echo '</script>';
    }else {
      function verify(){
        $unique_id=uniqid();
        //$verification_code=substr(bin2hex(random_bytes(16)),0,12);
        $newNumber = strval(mt_rand(100000000000, 999999999999));
        return  $newNumber;
      }
      $check=verify();
      
      function recu($check){
        $conn = new mysqli('localhost', 'root', '', 'project');
        $sql = "SELECT Request_Id FROM request WHERE Request_Id='$check'";
        $result = $conn->query($sql);
        if($result->num_rows > 0) {
            $check=verify();
           return recu($check);
           exit;
        }else{
          return $check;
        }
      }
$checked=recu($check);
       $sql2 = "INSERT INTO `request` (`Request_Id`,`name`,`phone`,`id`,`date`,`expiry_time`,`num_person`,`source`,`destination`) 
       VALUES('$checked','$name','$phone','$Id','$dat','$expiry_time','$num','$origin','$destination')";
            if ($result = $conn->query($sql2)) {
                include "paypop.php";
                echo '<script type="text/javascript">';
                echo 'var modal = document.getElementById("myModal");';
                echo 'modal.style.display = "block";';
                echo '</script>';
             //send sms goes
    // $api_token = "1vdqBtpgAKzX2P2PRE4380QGSL8W9SjA";
    // $from = "9481";
    // // $to = $phone;
    // $message = "Dear ".strtoupper($name)." This Is your Identification code Please keep it. ".$checked;
    
    // $dataaa = array(
    //     'token' => $api_token,
    //     'phone' => $phone,
    //     'msg' => $message,
    //     'shortcode_id=9481',
    // );
    
    // $ch = curl_init('https://api.geezsms.com/api/v1/sms/send');
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($ch, CURLOPT_POST, true);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, $dataaa);
    // $result = curl_exec($ch); 
    // curl_close($ch);

     

            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        $conn->close();


    }
}else{
  include "passedpopup.php";
  echo '<script type="text/javascript">';
  echo 'var modal = document.getElementById("myModal");';
  echo 'modal.style.display = "block";';
  echo '</script>';

}
?>
