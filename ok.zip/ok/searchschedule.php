<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="beauty.css">
    <style>
    @media screen and (max-width:768px){
.ayt{
  display: flex !important;
  flex-wrap: wrap !important;
  margin:  auto;
  margin-top: 150px;
  width: 300px !important;
  height: 60vh !important;
  padding: 0 !important;

}
.tupil{
  margin: auto;
  padding: 0;
}
    }
    </style>
</head>
<body style="background:url('blacktrain.jpg');
	background-size: 100% 100%;
background-repeat: no-repeat;
background-position: fixed;">
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="adminlog.php">Login</a></li>
          </ul>
        </nav>
    
    </header>

		<div class="ayt" id="cont">
      <!-- <h2 class="tupil">Train Schedule Checker: Find Your Route and Departure Time<h2> -->
      
      <h2 class="tupil">Train Schedule Checker: Search Your Trip Time by Date & Route</h2>

            <form  method="post" id="myform" action="">
                <label class="ff" id="ori">Origin:</label>
         <select name="source" id="origin" class="select" required>
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option value="Alisabeh">Alisabeh</option>
            <option value="Nagada">Nagada</option>
        </select><br><br>
        <label class="ff" id="desti">Destination:</label>
         <select name="destination" id="destination" class="select" required>
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option value="Alisabeh">Alisabeh</option>
            <option value="Nagada">Nagada</option>
        </select><br><br>
        <label class="ff" id="deti">Date:</label>
        <input type="date" name="datee" required="" id="date" class="select2"><br><br>
        <input type="reset" name="reset" value="reset" class="sub2" >
        <input type="submit" name="insert" value="search" class="sub" >
    </form>
    <script type="text/javascript">

const form = document.getElementById("myform");
const dateInput = document.querySelector('#date');
//action="search.php"
let dbool=false;
let sbool=false;
dateInput.addEventListener("input", (event) => {
    const currentDate = new Date();
    const inputDate = event.target.value;
    const dateParts = inputDate.split("-");
    const year = parseInt(dateParts[0]);
const month = parseInt(dateParts[1]) -1; // month is 0-based
const day = parseInt(dateParts[2]) + 1;
const datenew = new Date(year, month, day);
const timezoneOffset = datenew.getTimezoneOffset() * 60 * 1000; // in milliseconds
datenew.setTime(datenew.getTime() + timezoneOffset);

    if (datenew.getTime() < currentDate.getTime()) {
      event.target.setCustomValidity("Invalid date");
    } else {
      event.target.setCustomValidity("");
      dbool=true;
    }
  });




const origin = document.getElementById('origin');
const destination = document.getElementById('destination');

// Set initial values in local storage
localStorage.setItem('originvalue', origin.value);
localStorage.setItem('destinationvalue', destination.value);

// Add event listener to form element for handling changes
form.addEventListener('change', (event) => {
  // Check if the changed element is either the origin or destination field

  if (event.target === origin || event.target === destination) {
    // Update local storage with new value
    localStorage.setItem(`${event.target.id}value`, event.target.value);
  }
  
  // Check if origin and destination values are the same

  if (localStorage.getItem('originvalue') === localStorage.getItem('destinationvalue')) {
    event.preventDefault();
    destination.setCustomValidity('Please select a different destination');
  } else {
    destination.setCustomValidity('');
  }
 });
// var element=document.getElementById("cont");
// var margine=window.getComputedStyle(element).getPropertyValue("margin");
// var padding=window.getComputedStyle(element).getPropertyValue("padding");
// var height=window.getComputedStyle(element).getPropertyValue("height");
// var width=window.getComputedStyle(element).getPropertyValue("width");
// alert("The margin ="+margine+"\nThe padding ="+padding+"\n height="+height+"\n width="+width);
         </script>
        
        </div>
        <footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>		
        <script src="beauty.js"></script>
</body>
</html>

<?php


// $fromm =$_POST['source'];
// $too =$_POST['destination'];
// $datee =$_POST['datee'];



// $search = $_POST['datee'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}
if (isset($_POST['source'])  && isset($_POST['destination'])  && isset($_POST['datee'] )){
$sql = "SELECT * FROM schedule WHERE date LIKE '%" . $_POST['datee'] . "%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    if ($_POST['source'] == $row['source'] && $_POST['destination'] == $row['destination'] && $_POST['datee'] == $row['date']) {
      //session_start();
      $_SESSION['data'] = $_POST['datee'];
      $_SESSION['datas'] = $_POST['source'];
      $_SESSION['datad'] = $_POST['destination'];
      //echo $_SESSION['data'];
      header("Location: found.php");
      echo '<script>';
      echo 'window.location.href="found.php";';
      echo '</script>';
       exit; // add exit to stop script execution
    }
  }
  // If no matching rows found
  include 'popup.php';
  echo '<script>';
  echo 'var modal = document.getElementById("myModal");';
  echo 'modal.style.display = "block";';
  echo '</script>';
} else {
  // If no rows found
  include 'popup.php';
  echo '<script>';
  echo 'var modal = document.getElementById("myModal");';
  echo 'modal.style.display = "block";';
  echo '</script>';
}

$conn->close();
}
?>





