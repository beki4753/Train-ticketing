function Validation()
{


var name = document.rr.name;

var uemail = document.rr.email;
var phone = document.rr.phone;
var idd = document.rr.idd;
var ttno = document.rr.ttno;



if(allLetter(name))
{

if(ValidateEmail(uemail))
{
if(numeric(phone))
{	
if(allnumerici(idd))
{
if(allnumerict(ttno))
{	

 
}   
}   
}   
}   
  
}


return false;

} 


function allLetter(name)
{ 
var letters = /^[A-Z a-z]+$/;
if(name.value.match(letters))
{
return true;
}
else
{
alert('Name must have alphabet characters ');
name.focus();
return false;
}
}


function ValidateEmail(uemail)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(uemail.value.match(mailformat))
{
return true;
}
else
{
alert("You have entered an invalid email address!");
uemail.focus();
return false;
}
} 

function numeric(phone)
{ 
var numbers = /^[0-9]+$/;
if(phone.value.match(numbers))
{
return true;
}
else
{
alert('Phone code must have numeric characters only');
phone.focus();
return false;
}
}

function allnumerict(ttno)
{ 
var numbers = /^[0-9]+$/;
if(ttno.value.match(numbers))
{
return true;
}
else
{
alert('tt number must have numeric characters only');
ttno.focus();
return false;
}
}

function allnumerii(idd)
{ 
var numbers = /^[0-9]+$/;
if(idd.value.match(numbers))
{
return true;
}
else
{
alert('Id must have numeric characters only');
idd.focus();
return false;
}
}







