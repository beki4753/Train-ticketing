<?php

// Connect t o database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve form data
    $name = $_POST['Name'];
    $email = $_POST['Email'];
    $phone = $_POST['Phone'];
    $Id = $_POST['idd'];
    $Date = $_POST['Date'];
    $num = $_POST['num'];
    $origin = $_POST['origin'];
    $destination = $_POST['destination'];
    $ttno = $_POST['ttno'];

    // Validate form data
    if (empty($name) || empty($email) || empty($phone) || empty($Id) || empty($Date) || empty($num) || empty($origin) || empty($destination) || empty($ttno)) {

        echo '<script type="text/javascript">';
        echo 'window.alert("Please fill all the fields");';
        echo 'window.location.replace("reservation.php");';
        
        echo '</script>';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<script type="text/javascript">';
        echo 'window.alert("Invalid email format");';
        echo 'window.location.replace("reservation.php");';

        echo '</script>';
    } else {

        // Check if data already exists
        $sql = "SELECT * FROM payment WHERE tno = '$ttno' ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo '<script type="text/javascript">';
            echo 'window.alert("Wrong TT number");';
            echo 'window.location.replace("reservation.php");';
            echo '</script>';
        } else {

            // Insert data into database
            $sql = "INSERT INTO payment (tno) VALUES ('$ttno')";
            if ($conn->query($sql) === TRUE) {

                echo '<script type="text/javascript">';
                echo 'window.alert("Data Submited successfully Wait for SMS");';
                echo 'window.location.href="reservation.php"';
                echo '</script>';
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}

// Close database connection
$conn->close();
?>
