<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$email="eyasu demis";
$sql = "SELECT `phone` FROM reservation WHERE name = '$email' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc() ){
        echo $row['phone'];
    }

}

date_default_timezone_set('Africa/Addis_Ababa');
$date = date('h:i');
echo $date;
?>