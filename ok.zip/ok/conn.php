<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$con = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

?>