const form = document.getElementById('form');
const name = document.getElementById('name');
const email = document.getElementById('email');
const phone = document.getElementById('phone');
const message = document.getElementById('message');

form.addEventListener('submit',(e) => {
e.preventDefault();

validateInputs();

});

const setError = (element, message) => {
const inputControl = element.parentElement;
const errorDisplay = inputControl.querySelector('.error');

errorDisplay.innerText = message;
errorDisplay.style.color = "red";
inputControl.classList.add('error');
inputControl.classList.remove('success');
}

const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');
    errorDisplay.innerText = '';
  
    inputControl.classList.add('success');
inputControl.classList.remove('error');
};

function validatePhoneNumber(input_str) 
{
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

    return re.test(input_str);
}

const isValidEmail = email => {
    const re = varpattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 
    return re.test(String(email).toLowerCase());
}

const validateInputs = () => {
const nameValue = name.value.trim();
const emailValue = email.value.trim();
const phoneValue = phone.value.trim();
const messageValue = message.value.trim();
if(nameValue === ''){
    setError(name, 'name is required');
} else {
setSuccess(name);
}
if(emailValue === ''){
    setError(email, 'Email is required');
} else if (!isValidEmail(emailValue)){
    setError(email, 'provide a valid email address');
} else {
    setSuccess(email);
}
if(phoneValue === ''){
    setError(phone, 'phone is required');
} else if (phoneValue.length < 10) {
setError(phone, 'phone must be 10 digit')
} else if (phoneValue.length > 10) {
    setError(phone, 'phone must be 10 digit')
    } else if(!validatePhoneNumber(phoneValue)) {
        setError(phone, 'phone must be number only')
      } else {
        setSuccess(phone);
      }

    if(messageValue === ''){
        setError(message, 'message is required');
    } else if(messageValue.length < 20 ){
        setError(message, 'message length should be great than 20 characters'); 
       
    } else {
    setSuccess(message);
  
    }
};



