<?php
$username =$_POST['username'];
$password =$_POST['password'];

//database connection
$conn = new mysqli('localhost','root','','project');
if($conn->connect_error){
	die('Connection Failed : '.$conn->connect_error);//making unique email and password not to duplicate
}else{
	$stmt = $conn->prepare("insert into admin(username,password)
		values(?,?)");
	$stmt->bind_param("si",$username,$password);
	$stmt->execute();

	echo "registration successfully...";
	$stmt->close();
	$conn->close();
}
?>