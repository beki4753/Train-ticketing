<?php
session_start();
// Connect t o database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function verify(){
    $unique_id=uniqid();
    //$verification_code=substr(bin2hex(random_bytes(16)),0,12);
    $newNumber = strval(mt_rand(100000000000, 999999999999));
    return  $newNumber;
}
$check=verify();

function recu($check){
    $sql = "SELECT * FROM verification WHERE code='$check'";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        $check=verify();
       return recu($check);
    }
}
$_SESSION['verification']=$check;
        $sql="INSERT INTO `verification`(`code`) VALUES ('$check')";
        $result2=$conn->query($sql);  
        if($result2) {
            echo "Inserted successfuly";
        }else{
            echo "Not Inserted!";
        }
//send sms goes

$email=$_SESSION['family'];
$sql = "SELECT `phone` FROM request WHERE email = '$email' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $api_token = "1vdqBtpgAKzX2P2PRE4380QGSL8W9SjA";
    $from = "9481";
    $to = "+251985818912";
    $message = "sera eko uuuuu";
    
    $data = array(
        'token' => $api_token,
        'phone' => $to,
        'msg' => $message,
        'shortcode_id=9481',
    );
    
    $ch = curl_init('https://api.geezsms.com/api/v1/sms/send');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $result = curl_exec($ch);   
    curl_close($ch);
}

// for ticket id 
//function verify(){
//     $unique_id=uniqid();
//     $verification_code=substr(bin2hex(random_bytes(16)),0,12);
//     return $verification_code;
// }
// $check=verify();

// function recu($check){
//     $sql = "SELECT * FROM verification WHERE code='$check'";
//     $result = $conn->query($sql);
//     if($result->num_rows > 0) {
//         $check=verify();
//        return recu($check);
//     }
// }
// echo $check;
//         $sql="INSERT INTO `verification`(`code`) VALUES ('$check')";
//         $result2=$conn->query($sql);  
//         if($result2) {
//             echo "Inserted successfuly";
//         }else{
//             echo "Not Inserted!";
//         }

//1000297200503   //1000382453631
//function generateUniqueNumber($db) {
//     $unique_id=uniqid();
//     $verification_code=substr(bin2hex(random_bytes(16)),0,12);
//     return $verification_code;


//     // generate a random 12-digit number
//     $newNumber = strval(mt_rand(100000000000, 999999999999));
  
//     // check if the number is already in the database
//     $query = "SELECT code FROM verification WHERE code = '$newNumber'";
//     $result = mysqli_query($db, $query);
  
//     if(mysqli_num_rows($result) > 0) {
//       // if the number is already in the database, generate a new one
//       $newNumber=generateUniqueNumber($db);
//       return $newNumber;
//     } else {
//       // if the number is not in the database, store it and return it
//       $query = "INSERT INTO verification (code) VALUES ('$newNumber')";
//       mysqli_query($db, $query);
//       return $newNumber;
//     }
//   }
  
//   // example usage
//   $db = mysqli_connect('localhost', 'root', '', 'project');
//   $uniqueNumber = generateUniqueNumber($db);
//   echo $uniqueNumber;

?>

<script>
let unique_id = Date.now().toString(36)+Math.random().toString(36).substr(2,5);
let verification_code = Math.floor(parseInt(unique_id,36)+Math.random()*46656).toString(36).substr(0,6);
console.log(verification_code);
</script>