// const form = document.querySelector('registr');
// const nameInput = document.querySelector('#name');
// const emailInput = document.querySelector('#email');
// const phoneInput = document.querySelector('#tel');
// const dateInput = document.querySelector('#date');
// const selection1 = document.querySelector('#origin');
// const selection2 = document.querySelector('#destination');
// const txnInput = document.querySelector('#tno');

// const today = new Date();
// const tomorrow = new Date(today);
// tomorrow.setDate(today.getDate() + 1);

// form.addEventListener('submit', (event) => {
//   if (!isNameValid()) {
//     nameInput.setCustomValidity('Please enter a valid name with only alphabets');
//   } else {
//     nameInput.setCustomValidity('');
//   }
  
//   if (!isEmailValid()) {
//     emailInput.setCustomValidity('Please enter a valid email address');
//     if (!isPhoneValid()) {
//       phoneInput.setCustomValidity('Please enter a valid phone number starting with +251');
//       if (!isDateValid()) {
//         dateInput.setCustomValidity(`Please enter a valid date on or after ${tomorrow.toISOString().slice(0, 10)}`);
//         if (!isSelectionValid()) {
//           selection2.setCustomValidity('Please make a different selection from the first one');
//           if (!isTxnValid()) {
//             txnInput.setCustomValidity('Please enter a valid transaction ID with only numbers and alphabets, up to 10 characters');
//             if (!form.checkValidity()) {
//               event.preventDefault();
//             }
//           } else {
//             txnInput.setCustomValidity('');
//           }
//         } else {
//           selection2.setCustomValidity('');
//         }
//       } else {
//         dateInput.setCustomValidity('');
//       }
//     } else {
//       phoneInput.setCustomValidity('');
//     }
//   } else {
//     emailInput.setCustomValidity('');
//   }
// });

// function isNameValid() {
//   const name = nameInput.value.trim();
//   return /^[a-zA-Z]+$/.test(name);
// }

// function isEmailValid() {
//   const email = emailInput.value.trim();
//   return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
// }

// function isPhoneValid() {
//   const phone = phoneInput.value.trim();
//   return /^(\+251)\d{9}$/.test(phone);
// }

// function isDateValid() {
//   const date = new Date(dateInput.value.trim());
//   return date >= tomorrow && date <= new Date(date.getTime() + (24 * 60 * 60 * 1000));
// }

// function isSelectionValid() {
//   return selection1.value !== selection2.value;
// }

// function isTxnValid() {
//   const txn = txnInput.value.trim();
//   return /^[a-zA-Z0-9]{1,10}$/.test(txn);
// }


const form = document.querySelector('#myform');
const nameInput = document.querySelector('#name');
const phoneInput = document.querySelector('#tel');
const dateInput = document.querySelector('#date');
const selection1 = document.querySelector('#origin');
const selection2 = document.querySelector('#destination');
//const txnInput = document.querySelector('#tno');

const today = new Date();
const tomorrow = new Date(today);
tomorrow.setDate(today.getDate() + 1);

nameInput.addEventListener('input', () => {
  if (!isNameValid()) {
    nameInput.setCustomValidity('Please enter a valid name with only alphabets');
  } else {
    nameInput.setCustomValidity('');
  }
});

// emailInput.addEventListener('input', () => {
//   if (!isEmailValid()) {
//     emailInput.setCustomValidity('Please enter a valid email address');
//   } else {
//     emailInput.setCustomValidity('');
//   }
// });

phoneInput.addEventListener('input', () => {
  if (!isPhoneValid()) {
    phoneInput.setCustomValidity('Please enter a valid phone number starting with +2519');
  } else {
    phoneInput.setCustomValidity('');
  }
});

dateInput.addEventListener('input', () => {
  if (!isDateValid()) {
    dateInput.setCustomValidity(`Please enter a valid date on or after ${tomorrow.toISOString().slice(0, 10)}`);
  } else {
    dateInput.setCustomValidity('');
  }
});

selection2.addEventListener('input', () => {
  if (!isSelectionValid()) {
    selection2.setCustomValidity('Please make a different selection from the first one');
  } else {
    selection2.setCustomValidity('');
  }
});

// txnInput.addEventListener('input', () => {
//   if (!isTxnValid()) {
//     txnInput.setCustomValidity('Please enter a valid transaction ID');
//   } else {
//     txnInput.setCustomValidity('');
//   }
// });

// function isNameValid() {
//   const name = nameInput.value.trim();
//   return /^[a-zA-Z]+$/.test(name);
// }
function isNameValid() {
  const name = nameInput.value.trim();
  return /^[a-zA-Z\s]+$/.test(name);
}

// function isEmailValid() {
//   const email = emailInput.value.trim();
//   return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
// }

function isPhoneValid() {
  const phone = phoneInput.value.trim();
  return /^(\+2519)\d{8}$/.test(phone);
}

function isDateValid() {
  const date = new Date(dateInput.value.trim());
  return date >= tomorrow && date <= new Date(date.getTime() + (24 * 60 * 60 * 1000));
}

function isSelectionValid() {
  return selection1.value !== selection2.value;
}

// function isTxnValid() {
//   const txn = txnInput.value.trim();
//   return /^[a-zA-Z0-9]{1,10}$/.test(txn);
// }
// function isTxnValid() {
//   const txn = txnInput.value.trim();
//   if (!txn) {
//     return false;
//   }
//   return /^[a-zA-Z0-9]$/.test(txn);
// }

form.addEventListener('submit', (event) => {
  if (!form.checkValidity()) {
    event.preventDefault();
  }
});

