<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="author" content="Brad Traversy">   
      <title>Train Ticketing | contact us</title>
  <link rel="stylesheet" href="contac.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="beauty.css">
<script defer src="./contact.js"></script>
<script defer src="beauty.js"></script>

</head>
<!-- Bootstrap CSS -->

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<body>

<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="customerannouncement.php">Announcment</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="adminlog.php">Login</a></li>
            <li><a href="./Admin/send.php" id="send">Pay</a></li>
          </ul>
        </nav>
      </div>
    </header>



<div class="containers"> 
   <div class="contact-parent">
      <div class="contact-child child1">
         <p>
            <i class=></i> Address <br />
            <span> Gbekh developers
            <br />
            Addiss Abeba, Ethiopia
            </span>
         </p>
         <p>
            <i class="fas fa-phone-alt"></i> Let's Talk <br />
            <span>0931857555</span><br />
      <span>0953753505</span>
         </p>
          <p>
            <i class=" far fa-envelope"></i> Account number: <br />
            <span>Dashin Bank:  4086</span><br>
            <span>CBE:           2236</span><br>
            <span>Brihan Bank:  3225</span>
         </p>
         <p>
            <i class=" far fa-envelope"></i> General Support <br />
            <span><a href="https:// www.gmail.com/brackgech@gmail.com">brackgech@gmail.com</a></span>
         </p>
      </div>
      
      <form id="form"  method="GET">
      <div class="contact-child child2">
         <div class="inside-contact">
            <h2>Contact Us</h2>
            <h3> 
               <span id="confirm">
            </h3>
          <div class="input-control">
             <label for="name">Name</label>
             <input  id="name" name="name"  type="text" placeholder="enter your name" id="name">
             <div class="error"></div>
            </div>
            <div class="input-control">
               <label for="email">Email</label>
               <input id="email" name="email" type="text" placeholder="enter your email">
            <div class="error"></div>
              </div>
             <div class="input-control">
             <label for="phone">phone</label>
             <input id="phone" name="phone" type="tel" placeholder="enter your phone number">  
              <div class="error"></div>
            </div>
            <div class="input-control">
            <label for="message">Message</label>
            <textarea id="message" rows="4" cols="20" Required="required" placeholder= "type your message">   </textarea>
           <div class="error"></div>
            </div>
           
           <button type="submit"> Submit  </button>
       
           
      </div>
      
      </div>
         
   </form>
   
   </div>
   <script src="contact.js"></script>
</div>

<footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>
<body>
</html>