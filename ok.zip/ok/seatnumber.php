<?php 
session_start();
$count =$_SESSION['count'];
$number=$_SESSION['wenber'];

?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Seats</title>
<!-- <link rel="stylesheet" type="text/css" href="progress.css"> -->
<style>
      
      * {
        margin: 0;
        border: 0;
        box-sizing: border-box;
      }
      @import url("https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700");
      @import url("https://fonts.googleapis.com/css?family=Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i");
      
      
      :root {
        --font-roboto: "Roboto Slab", serif;
        --font-raleway: "Raleway", sans-serif;
      }
      
      body {
        font-family: var(--font-roboto);
        background-color: #fff;
      }
      .outer{
    width: 160px;
    height: 160px;
    border-radius: 50%;
    padding: 20px;
   box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.15),
               -6px -6px 10px -1px rgba(255,255,255,0.7);

}
.inner{
    width: 120px;
    height: 120px;
    border-radius: 50%;
    box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
               inset -4px -4px 6px -1px rgba(255,255,255,0.7),
               -0.5px -0.5px 0px rgba(255,255,255,1),
               0.5px 0.5px 0px rgba(0,0,0,0.05),
               0px 12px 10px -10px rgba(0,0,0,0.05);
display: flex;
align-items:center;
justify-content: center;
}

circle{
    fill: none;
    stroke: url(#GradientColor);
    stroke-width:20px;
    /* stroke-dasharray: 472; */
    /* stroke-dashoffset: 472; used to animat the cicrcle */
    animation: anim 2s linear forwards;
}

svg{ 
position: absolute;
right: -3rem;
top: 0;
left: 0;
}
path{
    stroke-dasharray: 100;
    stroke-dashoffset: var(--offset,0);
    animation: anim 3s linear forwards;
}
@keyframes anim{
    100%{
    stroke-dashoffset: var(--offset, 0);  
    }
}
      .app {
        padding: 4rem;
      
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
      }
      
      .h1 {
        font-size: 3rem;
        letter-spacing: 0.9px;
        background: linear-gradient(
          90deg,
          rgba(249, 211, 180, 1) 0%,
          rgba(249, 211, 180, 0) 100%
        );
        background-clip: text;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        width: fit-content;
      }
      
      
      .Container {
        width: 100%;
        margin-top: 3rem;
      
        display: flex;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
      }
      
      .movie {
        width: 310px;
        height: 460px;
        margin: 1.5rem;
      
        position: relative;
        border-radius: 12px;
        overflow: hidden;
        border: none;
        justify-content: center;
        align-items: center;
        float: center;
        display: block;
        right: -3rem;
        top: 5rem;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0, 1);
        box-shadow: 0px 13px 10px -7px rgba(0, 0, 0, 0.1);
      }
      
      @media screen and (max-width: 600px) {
        .app {
          padding: 4rem 2rem;
        }
      
      }
      
      @media screen and (max-width: 400px) {
        .app {
          padding: 4rem 1rem;
        }
      
        .h1 {
          font-size: 2rem;
        }
      
        .container {
          margin-top: 2rem;
        }
      
        .movie {
          width: "100%";
          margin: 1rem;
        }
      }
          </style>
</head>
<body >
<div class="movie ">
    
<div class="outer">
<div class="inner">
<div id="number">
    
</div>
</div>
</div>

<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="160px" height="160px">
  <defs>
    <linearGradient id="GradientColor">
      <stop offset="0%" stop-color="#e91e63" />
      <stop offset="100%" stop-color="#673ab7" />
    </linearGradient>
  </defs>
  <circle cx="80" cy="80" r="70" stroke="#ddd" stroke-width="8" fill="none" stroke-linecap="round" stroke-dasharray="439.82297150257" stroke-dashoffset="439.82297150257" transform="rotate(-90 80 80)" />
  <circle id="progress" cx="80" cy="80" r="70" stroke="url(#GradientColor)" stroke-width="8" fill="none" stroke-linecap="round" stroke-dasharray="439.82297150257" stroke-dashoffset="439.82297150257" transform="rotate(-90 80 80)" />
  <text id="number" x="50%" y="50%" text-anchor="middle" alignment-baseline="central" font-size="24px" font-weight="bold"></text>
</svg>
</div>

<script>
    function myfunction(myVariable){
       return myVariable;
    }
  
    let progress = document.getElementById("progress");
    let number =document.getElementById("number");
    let circle= document.querySelector('circle');
    let counter =0;
    let counte =myfunction(<?php echo $count; ?>);
    let number2 = myfunction(<?php echo $number; ?>);
    let difference = number2 - counte;
    
    let percent= (100*difference)/number2;
    let intervalTime = 1000/ (percent+1000); // calculate the interval time based on the counter value
//     let minInterval = 10; // minimum interval in milliseconds
// let maxInterval = 100; // maximum interval in milliseconds
// let minCounter = 0; // minimum counter value
// let maxCounter = 100; // maximum counter value

// function getInterval(counter) {
//   // calculate the interval and stroke dash offset based on the counter value
//   let interval = (maxCounter - counter) / (maxCounter - minCounter) * (maxInterval - minInterval) + minInterval;
//   let strokeDashOffset = 440 - (440 * counter) / 100;
//   return { interval, strokeDashOffset };
// }
// let { interval, strokeDashOffset } = getInterval(counter);
let intervalId = setInterval(()=>{
        if(counter === percent|| counter ===100){
            clearInterval(intervalId);
            number.innerHTML= counter+"%";
        }else{
            counter+=1;
        number.innerHTML= counter+"%";
      //   let strokeOffset = 472 - (472 * (counter) / 100);
      // progress.style.strokeDashoffset = strokeOffset;
    }


    let strokeOffset = 472 - (472 * (counter) / 100);
      // progress.style.strokeDashoffset;
      progress.style.strokeDasharray = strokeOffset;
      // progress.style.strokeDashoffset = strokeOffset;
      // stroke-dasharray
    }, intervalTime );
</script>
    </body>
</html>
