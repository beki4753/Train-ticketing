// const form = document.getElementById("myform"); 
// form.addEventListener("submit", function(event) { 
//     event.preventDefault();
//     if (abc()) { 
//         form.submit(); 
//     } }); 

//     function abc(){
//         selectElement=document.querySelector('#origin');
//         var a=selectElement.value;
//         selectElement=document.querySelector('#destination');
//     var b=selectElement.value;
    
   
//                     if (a === b) {
//                         return false;
//          window.alert("Incorrect selection Select correctly!!");
//          window.location.replace("reservation.php");
//     }else{
//         return true;
//     }
//     }

    const phoneField = document.getElementById("tel"); 
    phoneField.addEventListener("input", function(event) { 
        const phone = event.target.value; 
    if (!isValidPhone(phone)) { 
        phoneField.setCustomValidity("Please enter a valid phone number starting with +251"); 
    } else { phoneField.setCustomValidity(""); } 
    }); 
    function isValidPhone(phone) { 
        const phoneRegex = /^\+251\d{9}$/; 
        return phoneRegex.test(phone); 
    }



    // function validateForm() { 
    //     const name = document.getElementById("name").value;
    //     const email = document.getElementById("email").value;
    //     const phone = document.getElementById("phone").value;
    //     const id = document.getElementById("id").value;
    //     const number = document.getElementById("number").value;
    //     const txnId = document.getElementById("txnId").value;
    //     //Validate name
    //     if (name === "") { 
    //         alert("Name must not be empty"); 
    //         return false; } 
    //         // Validate email 
    //     if (email === "") { 
    //         alert("Email must not be empty"); 
    //         return false; }
    //         // Validate phone number
    //     if (phone === "") { 
    //         alert("Phone number must not be empty"); 
    //         return false; } 
    //         // Validate ID 
    //     if (id === "") { 
    //         alert("ID must not be empty"); 
    //         return false; } 
    //         // Validate number 
    //     if (number === "") { 
    //         alert("Number must not be empty"); 
    //         return false; } 
    //         // Validate transaction ID 
    //     if (txnId === "") { 
    //         alert("Transaction ID must not be empty");
    //         return false; 
    //     } 
    //     return true; 
    // } 
