
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="train metro ticketing system">
   <meta name="keywords" content="train ticketing,train metro ticketing system , ticketing system">
   <meta name="author" content="Brad Traversy">
    <title>About</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="beauty.css">
  </head>
  <body>
  <header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="customerannouncement.php">Announcment</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="adminlog.php">Login</a></li>
            <li><a href="./Admin/send.php" id="send">Pay</a></li>
          </ul>
        </nav>
      </div>
    </header>
    
    <br></br>
        <br></br>
        
  
    <section id="newsletter">
      <div class="container">
  
      </div>
    </section>

    <section id="main">
      <div class="container">
        <article id="main-col">
          <h1 class="page-title">About Us</h1>
          <p>
             We started Train/Metro Ticketing System because ther are so many wastage of paper and time in our country.when a person wants to travel using train he/she weast time to have a ticket and some times they losse a chance to have a ticket and delay their travel schedul becase of traditional way used their.
          </p>
          <p class="dark">
That's Why our system become the only solution for this problem,By using this system web any one can have ticket properly even with out weasting time and other additonal effort on it.He/She also have digital ticket and can also print the ticket if he or she wants.
          </p>
        </article>

        <aside id="sidebar">
          <div class="dark">
            <h3>We Want To Be</h3>
            <p>The compitent system provider for ticketing.
               The solution for problem.
               Best site ever lasting system
               </p>
          </div>
        </aside>
      </div>
    </section>

    <footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>
    <script src="beauty.js"></script>
  </body>
</html>