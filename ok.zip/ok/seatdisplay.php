<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="beauty.css">
</head>
<body style="background:url('blacktrain.jpg');
	background-size: 100% 100%;
background-repeat: no-repeat;
background-position: fixed;">
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="login.php">Login</a></li>
          </ul>
        </nav>
    
    </header>

		<div class="bb">
    <iframe src="seatnumber.php" frameborder="0" width="500" height="350";  ></iframe>
    <iframe src="dispfram.php" frameborder="0" width="500" height="350";  ></iframe>
    <!-- <iframe src="seatnumber.php" frameborder="0" width="500" height="350";  ></iframe>
    <iframe src="seatnumber.php" frameborder="0" width="500" height="350";  ></iframe> -->

        </div>
        <footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>		
        <script src="beauty.js"></script>
</body>
</html>






