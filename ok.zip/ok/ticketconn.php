<?php 
  $name = $_POST['Name'];
  $phone = $_POST['Phone'];
  $id = $_POST['idd'];
  $date = $_POST['Date'];
  $origin = $_POST['origin'];
  $destination = $_POST['destination'];

  //database connection
  $conn = new mysqli('localhost','root','','practice');
  if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);//making unique email and password not to duplicate
  }else{
         try{
    $stmt = $conn->prepare("insert into reservation(name,phone,id,date,origin,destination)
      values(?,?,?,?,?,?)");
    $stmt->bind_param("sissss",$name,$phone,$id,$date,$origin,$destination);
    $stmt->execute();
   
    echo "<h1>loaded successfully...</h1>";
    // header("Location: print.php");
    $stmt->close();
    $conn->close();
         }catch(Exception $e){
           echo "Message".$e->getMessage();
         }
  }
  ?>