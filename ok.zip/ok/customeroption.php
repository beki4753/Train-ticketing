
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation</title>
    <link rel="stylesheet" href="customerreservation.css">
    <link rel="stylesheet" href="style.css">
     <script type="text/javascript" src="ss.js"></script>
</head>
<body class="body">


<script>
  function passvalue(){
    var name=document.getElementById("name").value;
    localStorage.setItem("emailvalue",name+"<br>");
    // var email=document.getElementById("email").value;
    // localStorage.setItem("emailvalue",email+"<br>");
    var phone=document.getElementById("tel").value;
    localStorage.setItem("telvalue",phone+"<br>");
    var id=document.getElementById("id").value;
    localStorage.setItem("idvalue",id+"<br>");
    var date=document.getElementById("date").value;
    localStorage.setItem("datevalue",date+"<br>");
    var time=document.getElementById("time").value;
    localStorage.setItem("timevalue",time+"<br>");
    var npp=document.getElementById("np").value;
    localStorage.setItem("numbervalue",npp+"<br>");
    var origin=document.getElementById("origin").value;
    localStorage.setItem("wordvalue",origin+"<br>");
    // document.print("DESTINATION: ");
    var destination=document.getElementById("destination").value;
    localStorage.setItem("textvalue",destination);
  }
</script>



          <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="services.php">Services</a></li>
          </ul>
        </nav>
      </div>
    </header> 
    <div class="al">
        <div class="h">
    <h1>I want Reserve seat</h1>
    <h3>of a train to travel</h3>
    </div>
    <form action="print.php" name='rr' onSubmit="return Validation();" class="ty" onSubmit="abc()">
<br><input id="name" placeholder="Name" type="text" class="kk" name="Name"><br><br>
        <input id="email" type="email" placeholder="your@email.com" class="kk" name="Email"><br><br>
        <input id="tel" type="tel" placeholder="Phone Number" class="kk" name="Phone" max="10"><br><br>
        <input id="id" type="id" placeholder="ID Number" class="kk" name="idd"><br><br>
        <input type="date" name="Date" id="date" class="kk" required="required"><br><br>
        
        <input type="number" name="number" id="np" placeholder="Number of people" class="kk"><br><br>
         <label class="jk">origin</label>
         <select name="origin" id="origin" required="required">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select>
        <label class="jk">     Destination</label>
         <select name="destination" id="destination" required="required">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option value="Alisabeh">Alisabeh</option>
            <option value="Nagada">Nagada</option>
        </select><br><br>
        <input type="text" name="ttno" placeholder="TT Number" class="kk" required="required"><br><br>
        <input type="reset" value="reset" class="tt"><br><br>
        <input type="submit" value="submit" class="tt" name="log" onclick="passvalue();"><br><br>
        <a href="take ticket.php" style="">take ticket</a>
           <script type="text/javascript">

            function abc(){
                selectElement=document.querySelector('#origin');
                var a=selectElement.value;
                selectElement=document.querySelector('#destination');
            var b=selectElement.value;
            
           
                            if (a === b) {
                 window.alert("Incorrect selection Select correctly!!");
                 window.location.replace("customeroption.php");
            }
            }
            

        </script>
    </form>
    </div>

    
</body>
</html>