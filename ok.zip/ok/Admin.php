<?php
session_start();
if(!$_SESSION["username"]){
  header("Location: adminlog.php");
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="train metro ticketing system">
   <meta name="keywords" content="train ticketing,train metro ticketing system , ticketing system">
   
   <meta name="author" content="Brad Traversy">
    <title>Admin Page</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="adstyle.css">
    <link rel="stylesheet" href="s.css">
    <style>
    .togler{
  display: none;
  background:#35424a;
  padding: 0px;
  align-items: center;
  /* border: 1px solid black; */
}
.togler img{
width: 30px;
height: 30px;

}

.show{
  display: block;
  background:#35424a;
  color:#ffffff;
  padding-top:30px;
  z-index: 999;
  justify-content: flex-start;
align-items: center;
float: center;
}
.show li{
  float: left;
  justify-content: flex-start;
align-items: center;
  display: flex;
  flex-wrap:wrap;
  flex-basis: auto;
}
        @media screen and (max-width: 768px) {
          .button_1{
display: flex;
align-items: center;
height:20px;
  width: 110px;
  background:#e8491d;
  border:1px solid black;
  padding: 10px;
padding-left: 50px;
  color:#ffffff;
  text-decoration: none;
 text-align: center;
 margin: auto;
}

        .navbar:not(.show){
            display: none;
        }
        .title{
          width: 10vw;
          margin-left: -0.3vw;
        }
        .show{
          display: -ms-flexbox !important;
    display: flex !important;
    -ms-flex-preferred-size: auto;
    flex-basis: auto;
        }
.togler{
  display: block;
width: 2rem;
height: 2rem;
margin-left: 65vw;
align-items: center;
}

    }
    #newsletter{
      display: flex;
      flex-wrap: wrap;
    }
    @media screen and (max-width:319px){
      .navbar:not(.show) {
            display: none;
        }
      .title h1{
          display: flex;
          flex-wrap: wrap;
        }
        .togler{
  display: block;
}
.show{
          display: -ms-flexbox !important;
    display: flex !important;
    -ms-flex-preferred-size: auto;
    flex-basis: auto;
        }          
.button_1{
display: flex;
 align-items: center;
  height:20px;
 width: 110px;
 background:#e8491d;
 border:1px solid black;
 padding: 10px;
 color:#ffffff;
 text-decoration: none;
text-align: center;
margin: auto;
}


header ul li:hover .sub3{
  display: block;
  position:fixed;
  background:#35424a;
  color:#ffffff;
  padding-top:30px;
  min-height:70px;
  border-bottom:#e8491d 3px solid;
  z-index: 999;

}

header ul li:hover .sub3 ul{
		display: block;
	    margin: 10px;
}

header ul li:hover .sub3 ul li{
  float:left;
  display:inline;
  padding: 0 20px 0 20px;
}

header ul li:hover .sub3 ul li:last-child{
	border-bottom: none;
}

    }
    .navbar {
transition: background-color 0.5s ease-in-out;
}

.navbar-scrolled {
background-color: rgba(52, 58, 64, 0.3) !important;
border-bottom: none;

}
/* .logout{
  display:block;
  width: 100vw;
  height: 50vh;
  margin: 0;
  position:relative;
} */
.sub3{
	display: none;
	transition-delay:5s ease-in-out;

}

header ul li:hover .sub3{
  display: block;
	position: absolute;
	background-color:#35424a;
	width: 200px;
	margin-top: 25px;
	margin-left: 10px;
}

header ul li:hover .sub3 ul{
		display: block;
	    margin: 10px;
}

header ul li:hover .sub3 ul li{
	width:150px;
	padding: 10px;
	border-bottom: 1px dotted #fff;
	background: transparent;
	border-radius: 0;
	text-align: left;
}

header ul li:hover .sub3 ul li:last-child{
	border-bottom: none;
}
#news{
display: block !important;
margin-top: 100px !important;

}
.contain{
display: block !important; 
}
.button_2{
  margin-top: 20px;  
  margin-left: 10px;  
  border-radius: 1px;

  height:30px;
  width: 60px;
  background:#e8491d;
  color:#ffffff;
 text-align: center;
}
.spa{
  font-family: "Times New Roman";
  font-weight: bold;
  font-size: 1.2rem;
  color: white;
}
    </style>
  </head>
  
<body style="background: url('xx.jpg') !important;
 background-repeat: no-repeat !important;
 background-size: 100% 100% !important;
 background-attachment: fixed !important;
background-position: center !important;">

    <header>
      <div class="container">
      <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <button  class="togler "><img src="togler.png"/></button>
        <nav class="navbar">
          <ul>
            <li ><a href="../index.php" >Home</a></li>

            <li><a href="#">Schedule</a>
                <div class="sub3">
                  <ul>
                    <li><a href="schedulform.php">Add</a></li>
                    <li><a href="viewschedulehtm.php">View</a></li>
                  </ul>
                </div>

            </li>

            <li ><a href="adminannouncement.php">Add Announcment</a></li>
            <li ><a href="print.php">Accept</a></li>
          </ul>

        </nav>
        

        
      </div>
    </header>
    <section id="news">
<div class="contain">
 <span class="spa">Click here to</span><button class="button_2" > <a  href="logout.php" style="text-decoration: none; color: black; font-weight: bold;">Logout</a>
</button>
</div>
</section>
<div class="ay" style="overflow: scroll; width:90vw; height: 80vh; margin-top:20px; display: flex; flex-wrap: wrap;">
    <?php 
        
        $db = mysqli_connect("localhost", "root", "", "project");
        $sql = "SELECT * FROM images";
        $result = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_array($result)){
            echo "<div id='img_div' class='imgbut'>";
                echo "<img src='images/".$row['image']. "'>";
                echo "<p style='font-size: 20px; font-family: Time New Roman;'>".$row['text']. "</p>";
            echo "</div>";

        }

    ?>
</div>
<script>
document.querySelector('.togler').addEventListener('click', function(){
this.checked= !this.checked;
var navbar = document.querySelector('.navbar');
if(navbar.classList.contains('show')){
  navbar.classList.remove('show');
}
 else {
  navbar.classList.add('show');
 
}
});

window.addEventListener('scroll',function() {
    
    var navbar = document.querySelector('header');
if (window.scrollY > 20) {
navbar.classList.add('navbar-scrolled');

} else {
  navbar.classList.remove('navbar-scrolled');
 
}
});
</script>

</body>
</html>