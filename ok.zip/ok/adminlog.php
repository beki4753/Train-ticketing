<?php
 session_start();
//Database Configuration File
include('./Admin/includes/config.php');
//error_reporting(0);
if(isset($_POST['login']))
  {
 
    // Getting username/ email and password
     $uname=$_POST['username'];
    $password=$_POST['password'];
    // Fetch data from database on the basis of username/email and password
$sql =mysqli_query($con2,"SELECT username,password FROM admin WHERE (username='$uname' || EmailId='$uname')");
 $num=mysqli_fetch_array($sql);
if($num>0)
{
$hashpassword=$num['password']; // Hashed password fething from database
//verifying Password
if (password_verify($password, $hashpassword)) {
$_SESSION['login']=$_POST['username'];
    echo "<script type='text/javascript'> document.location = './Admin/dashboard.php'; </script>";
  } else {
echo "<script>alert('Wrong Password');</script>";
 
  }
}
//if username or email not found in database
else{
echo "<script>alert('User not registered with us');</script>";
  }
 
}
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
<meta name="description" content="train metro ticketing system">
   <meta name="keywords" content="train ticketing,train metro ticketing system , ticketing system">
   
   <meta name="author" content="Brad Traversy">
    <title>Train ticketing | login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="adminlogin.css">
    <link rel="stylesheet" href="beauty.css">
    <style>
@media screen and (max-width: 768px){
  .div {
          margin-left: 16vw;
width: 50vw;
height: 50vh;
        }
        .div .th{
          margin-left: 25vw;
       }

        .div .df{
          margin-left: 25vw;
        }
        .div .db{
margin-left: 30vw;
        }
        .tt{
    height: 8vh;
    width:70vw ;
    margin: 0px;

        }
        
}
      @media screen and (max-width: 320px){
        .div {
          margin-left: 0.9rem !important;
width: 50vw !important;
height: 50vh !important;
        }
        .div .th{
          margin-left: 30vw;
       }

        .div .df{
          margin-left: 25vw;
        }
        .div .db{
margin-left: 30vw;
        }

        .tt{
          
    height: 8vh !important;
    width:90vw !important;
    margin: 0px !important;

        }
      }
      </style>
</head>
<body style="background-size: 100% 100%;">
   
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php">Home</a></li>

          </ul>
        </nav>
      </div>
    </header>



    <div class="div">
        <br><br>
        <br><br>
        <br><br>
        <h1 class="th">Admin Login</h1>
       <form method="post">
       <b><label class="df">Username:</label></b>  <br><br>
         <input type="text" placeholder="Username" name="username" class="tt" autocomplete="off">
        <br><br>
       <b><label class="df">Password:</label></b>   <br><br>
         <input type="password" name="password" placeholder="password" class="tt" autocomplete="off">
         <br><br>
         
    <input type="submit" class="db" value="LOGIN" name="login">
    </form>
    <br><br>
   
    <br><br><br><br>
    </div>
    <script src="beauty.js"></script>

</body>
</html>