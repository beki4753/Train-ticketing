<?php 
  session_start();
  try{

  if(isset(!$_SESSION['Email'])){
   header("location: login.php");
  }
  else{
  	 header("location: customerreserv.php");
  }

}catch(Exception $e){
  echo "Message".$e->getMessage();}

?> 
