<?php
$datee =$_POST['datee'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "select * from schedule where date like '%$datee%'";

$result = $conn->query($sql);

if ($result->num_rows > 0){
	
while($row = $result->fetch_assoc() ){

	 echo $row["source"]."  ".$row["destination"]."  ".$row["date"]." ".$row["time"]."<br>";
}
} else {
	    echo '<script type="text/javascript">';
    echo 'window.alert("Train schedule Not Found");';
    
    echo 'window.location.href="searchschedule.php"';
    echo '</script>';
}

$conn->close();


?>