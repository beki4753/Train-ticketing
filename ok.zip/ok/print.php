<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";
$conn = new mysqli($servername, $username, $password, $dbname);
// Validate input
if (isset($_POST['name'])) {
  $request_id = htmlentities($_POST['name']);
  $sanitizedInput = filter_var($request_id, FILTER_SANITIZE_STRING);

//   SELECT request.Request_Id, request.name, request.phone, checked.date, checked.status
//   FROM request
//   JOIN checked ON request.Request_Id = checked.Request_Id
//   WHERE  request.Request_Id= ? AND checked.status = 'checked' AND checked.date= ?   

  $sql = "SELECT ticket.Ticket_Id as tid, ticket.origin as menesha, ticket.destination as medresha, ticket.date as ken, ticket.time as seat, ticket.person as bizat, ticket.Request_Id as id,  request.name as sm
  FROM ticket 
  JOIN request ON ticket.Request_Id = request.Request_Id
  WHERE Ticket_Id ='$sanitizedInput'";
    $request_result = $conn->query($sql);
  if($request_result->num_rows ===0) {

      ?>
<script>
alert("Ticket Not Found!");
window.location.href="index.php";
</script>
<?php
    }else{
        while ($row =$request_result->fetch_assoc() ) {
// Retrieve the ticket information
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="print.css">
</head>
<body>
    <div class="ticket">
        <div class="left">
            <div class="image">
                <p class="admit-one">
                    <span>train ticket</span>
                    <span>train ticket</span>
                    <span>train </span>
                </p>
                <div class="ticket-number">
                    <p>
                        <?php echo $row['tid']; ?>
                    </p>
                </div>
            </div>
            <div class="ticket-info">
                <p class="date">
                    
                    <p>take screenshot of this ticket<p>
       
                </p>
                <div class="show-name">
                    <h1>Train/metro Ticketing System</h1>
                    <h2>paid</h2>
                </div>
                <div class="time">
                    <p>Departure Time <span>  : </span> <?php
                    $readableTime = date("h:i A", strtotime( $row['seat']));
                    echo $readableTime;
                   ?> </p>
                    <p>Name => <span id="result"> <?php echo $row['sm']; ?>
                </span> </p>
                        <p>Date => <span id="result4">  <?php echo $row['ken']; ?></span> </p>
                        <!-- <p>Time => <span id="result4">  </span> </p> -->
                        <p>Origin => <span id="result6"><?php echo $row['menesha']; ?> </span> </p>
                        <p>Destination => <span id="result7"> <?php echo $row['medresha']; ?></span> </p>
                        <p>Passenger => <span id="result7"> <?php echo $row['bizat']; ?></span> </p>
                    </div>
                <p class="location">
                    <span>we provide the best for you</span>

                    <span class="separator"><i class="far fa-smile"></i></span>
                    
                    <span>Ethiopia</span>
                </p>

            </div>
        </div>

        <div class="right">
            <p class="admit-one">
                <span>TRAIN TICKET</span>
                <span>TRAIN TICKET</span>
                <span>TRAIN </span>
            </p>
            <div class="right-info-container">
                <div class="show-name">
                 
                </div>
                <div class="time">
                  
                    <p>EMAIL <span>ticket@gmail.com</span></p>
              
                </div>
                <div class="barcode">
                    <img src="printqr.jpg" alt="">
                </div>
                <p class="ticket-number">
                    #20030220
                </p>
                <p>                            </p>
                <p>                            </p>
                <span>IF YOU NEED INFORMATION</span>
                <p>   CALL <span>0931857555</span></p>
              
            <input onclick="myfun();" class="send" type="submit" value="print">
                <script>
                    function myfun(){
                    window.print();
                    }
                </script>
            </div>
        </div>
    </div>
</body>
</html>
<?php
}
    }
  }else{?>
  <script>
    alert("Some thing wrong!");
window.location.href="index.php";

<script>
<?php
}
?>