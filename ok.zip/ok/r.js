const form = document.getElementById("myform"); 
form.addEventListener("submit", function(event) { 
    event.preventDefault();
    if (formValidation()) { 
        form.submit(); 
    } }); 


function formValidation()
{


var name = document.registr.name;

var uemail = document.registr.email;
var tel = document.registr.tel;
var id = document.registr.id;
var tno = document.registr.tno;



if(allLetter(name))
{

if(ValidateEmail(uemail))
{
if(numeric(tel))
{	
if(allnumerici(id))
{
if(allnumerict(tno))
{	

 
}   
}   
}   
}   
  
}


return false;

} 


function allLetter(name)
{ 
var letters = /^[A-Z a-z]+$/;
if(name.value.match(letters))
{
return true;
}
else
{
alert('Name must have alphabet characters ');
name.focus();
return false;
}
}


function ValidateEmail(uemail)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(uemail.value.match(mailformat))
{
return true;
}
else
{
alert("You have entered an invalid email address!");
uemail.focus();
return false;
}
} 

function numeric(tel)
{ 
var numbers = /^[0-9]+$/;
if(tel.value.match(numbers))
{
return true;
}
else
{
alert('tel code must have numeric characters only');
tel.focus();
return false;
}
}

function allnumerict(tno)
{ 
var numbers = /^[A-Z a-z 0-9]+$/;
if(tno.value.match(numbers) & tno.value.lnght()>=10) 
{
return true;
}
else
{
alert('tt number must have numeric characters only');
tno.focus();
return false;
}
}

function allnumerii(id)
{ 
var numbers = /^[0-9]+$/;
if(id.value.match(numbers))
{
return true;
}
else
{
alert('Id must have numeric characters only');
id.focus();
return false;
}
}







