
<?php
$fromm =$_POST['source'];
$too =$_POST['destination'];
$datee =$_POST['datee'];

// $search = $_POST['datee'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "select * from schedule where date like '%$datee%'";

$result = $conn->query($sql);

if ($result->num_rows > 0){
	$row = $result->fetch_assoc(); 
// while($row = $result->fetch_assoc() ){
	if($fromm ==$row["source"] && $too ==$row["destination"] && $datee ==$row["date"]  ){
    echo '<script type="text/javascript">';
    echo 'window.alert("Train Found");';
    
    echo 'window.location.href="customeroption.php"';
    echo '</script>';
          // header("Location: reservation.php");
	}else{
    echo '<script type="text/javascript">';
    echo 'window.alert("Train Found  Price is 500birr Pleas pay by banck and send TT number");';
    
    echo 'window.location.href="searchschedule2.php"';
    echo '</script>';
	}
	// echo $row["source"]."  ".$row["destination"]."  ".$row["date"]." ".$row["time"]."<br>";
// }
} else {
	    echo '<script type="text/javascript">';
    echo 'window.alert("Train not Found");';
    
    echo 'window.location.href="searchschedule2.php"';
    echo '</script>';
}

$conn->close();



?>