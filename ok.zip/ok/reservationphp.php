<?php

$servername ="localhost";
$username   ="root";
$password   ="";
$dbname     ="our_data";
$conn =new mysqli($servername,$username,$password,$dbname);

if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$email=$_POST['Email'];
	$mobile=$_POST['mobile'];
	$password=$_POST['password'];
	$in="insert into student(Name,Email,mobile,password) values('$name','$email','$mobile','$password')";
	
	$result=mysqli_query($conn,$in);
	

    if($result){
    	header('location:cheredbconn.php');
    }
  else{
  	die(mysqli_error($conn));
  }

}
?>