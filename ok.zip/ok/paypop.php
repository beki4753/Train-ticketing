<?php
session_start();
$dead=$_SESSION['delete'];
?>
<style>
    .form-group {
  margin-bottom: 1rem;
}
.form-control {
  display: block;
  width: 85%;
  padding: 0.5rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.form-control:focus {
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.btn {
  display: inline-block;
  font-weight: 400;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  user-select: none;
  border: 1px solid transparent;
  padding: 0.5rem 1rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: all 0.15s ease-in-out;
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
.btn:hover {
  color: #fff;
  background-color: #0069d9;
  border-color: #0062cc;
}
.btn:focus {
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.btn:active {
  color: #fff;
  background-color: #0062cc;
  border-color: #005cbf;
}



.btn {
  display: inline-block;
  font-weight: 400;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  user-select: none;
  border: 1px solid transparent;
  padding: 0.2rem 0.5rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: all 0.15s ease-in-out;
  color: #fff;
  background-color: #ff7b00;
  border-color: #ff7bff;
margin-left: 550px;
}
.btn:hover {
  color: #fff;
  background-color: #d96900;
  border-color: #cc6200;
}
.btn:focus {
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.btn:active {
  color: #fff;
  background-color: #cc6200;
  border-color: #fb5c00;
}

.modal {
  display: none;
  flex-wrap: wrap;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0,0,0,0.4);
}

.modal-content {
  display: flex;
  flex-wrap: wrap;
  background-color: #fefefe;
  margin: 15% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 60vw;
  height: 350px;
  position: relative;
}

.close {
  color: #aaa;
  position: absolute;
  float: right !important;
  font-size: 28px;
  font-weight: bold;
  top:0;
  right:0;
  padding: 10px;
  padding-top: 0;
}


.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
.corect{
    font-family: "Times New Roman";
    font-size: 2em;
    margin-top:-25px;
    display:inline-block;
    text-transform: capitalize;
    color: red;
    float: center;
    align-items: center;
    justify-content: center;
    margin-left: 350px;
}
.icon{
    width: 450px;
    height: 250px;
    align-items: center;
    justify-content: center;
    display: block;
}
.big{
    font-size: 40px;
}
.form{
    display: block;
    margin-left: 400px;
    width: 30vw;
    height: 100px;
    margin-top: -170px;
    position: relative;
}
.notify{
    margin-top: -55px;
}
.not{
    font-family: "Times New Roman";
    font-weight: bold;
    font-size: 25px;
    margin: 0;
    padding: 0;
    display: flex;
    float: center;
    
}
@media screen and (max-width: 1045){
  .modal{
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    height: 100%;
    margin: auto;
  }
.modal-content{
display: flex;
flex-wrap: wrap;
width: 90%;
padding: 0;
height: auto;
overflow-y: auto;
margin: auto;
margin-top: 110px;
  }
.corect{
margin: auto;
}
.icon{
  margin: auto;
  margin-top: 0;
}

.form{
    display: flex;
    margin: auto;
    width: 100%;
    height: 300px;
    margin-left: 20px;

}
.notify{
    margin: 0 !important;
}

.form-control {

  width: 75%;

}
}

@media screen and (max-width: 768px){
  .modal{
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    height: 100%;
    margin: auto;
  }
.modal-content{
display: flex;
flex-wrap: wrap;
width: 90%;
padding: 0;
height: auto;
overflow-y: auto;
margin: auto;
margin-top: 110px;
  }


.corect{
margin: auto;
}
.icon{
  margin: auto;
  margin-top: 0;
}

.form{
    display: flex;
    margin: auto;
    width: 100%;
    height: 300px;
    margin-left: 20px;

}
.notify{
    margin-top: 3px;
}

.form-control {

  width: 75%;

}

}
.pay{
font-family: "Times New Roman";
font-weight: bold;
font-size: 1.5rem;
color: rgba(0,0,0,0.7);
margin-top: 50px;
}

.warn{
font-family: "Times New Roman";
margin-left: 460px;
margin-top: -130px;
display: block;
white-space: wrap;
right: 0;
float: right;
color: red;
}
.warn2{
font-family: "Times New Roman";
margin-left: 460px;
margin-top: -160px;
display: block;
right: 0;
float: right;
}
a{
    text-decoration: none;
    color: white;
}
</style>
<div>

</div>
<div id="myModal" class="modal">
  <div class="modal-content" id="modal2">
    <span class="close" id="cly">&times;</span>
    <p class="corect"><span class="big">W</span>arning!</p>
    <span class="not"><img class="icon" src="./images/modernight.jpg" alt="train image"></span>
    <span class="pay">&nbsp;You have to Pay up to&nbsp;<?php echo $dead  ?> '</span>
    <p class="warn">"If you dont pay in  minutes your request will be cancelled"</p>
    <p class="warn2">"Wait for SMS with your identification code."</p>
     <button class="btn"><a href="https://www.ethiotelecom.et/telebirr/utility-bill-payment-telebirr/">Pay Now!</a></button> 

  </div>
</div>
<script>

// var element=document.getElementById("cly");
// var margine=window.getComputedStyle(element).getPropertyValue("margin");
// var padding=window.getComputedStyle(element).getPropertyValue("padding");
// var height=window.getComputedStyle(element).getPropertyValue("height");
// var width=window.getComputedStyle(element).getPropertyValue("width");
// var float=window.getComputedStyle(element).getPropertyValue("float");
// alert("The margin ="+margine+"\nThe padding ="+padding+"\n height="+height+"\n width="+width+"\n float ="+float);

// Get the modal
var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
  window.location.href="reservation.php";

}

// Show the modal
//modal.style.display = "block";
function popup(){

document.getElementbYId("myModal").style.display="block";
}





const nameInput1 = document.getElementById('name');
const emailInput1 = document.getElementById('email');
const form2 = document.getElementById('form');
form2.addEventListener('change', () => {
  // nameInput1.addEventListener("input", function(event) { 
  //   const name = event.target.value; 
  // if (!isValidname(name)) { 
  //   num =1;
  //   nameInput1.setCustomValidity("Name field must contain only alphabet characters."); 
  // } else { nameInput1.setCustomValidity(""); } 
  // }); 
  const name = nameInput1.value; 
  function isValidname(name) { 
    const nameRegex = /^[a-zA-Z\s]+$/; 
    return nameRegex.test(name); 
  }
  if (!isValidname(name)) { 
    nameInput1.setCustomValidity("Name field must contain only alphabet characters."); 
  } else { nameInput1.setCustomValidity(""); } 

  // emailInput1.addEventListener("input", function(event) { 
  //   const email = event.target.value; 
  // if (!isValidemail(email)) { 
  //   num1=1;
  // emailInput1.setCustomValidity("Email field must be a valid email address."); 
  // } else { emailInput1.setCustomValidity(""); } 
  // }); 
  const email = emailInput1.value; 

  function isValidemail(email) { 
    const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
    return emailRegex.test(email); 
  }
  if (!isValidemail(email)) { 
  emailInput1.setCustomValidity("Email field must be a valid email address."); 
  } else { emailInput1.setCustomValidity(""); } 

});




</script>
