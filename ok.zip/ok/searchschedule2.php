<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
</head>
<body >
	
		<div class="container">
            <form action="search2.php" method="post">
                <label class="ff">Origin</label>
         <select name="source" id="s">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select><br><br>
        <label class="ff">     Destination</label>
         <select name="destination" id="d">
            <option value="Adama">Adama</option>
            <option value="Meiso">Meiso</option>
            <option value="Dire Dawa">Dire Dawa</option>
            <option >Alisabeh</option>
            <option >Nagada</option>
        </select><br><br>
        <input type="date" name="datee" required=""><br><br>
        <input type="reset" name="reset" value="reset" class="sub2">
        <input type="submit" name="insert" value="search" class="sub" onclick="abc()">
    <script type="text/javascript">

            function abc(){
                selectElement=document.querySelector('#s');
                var a=selectElement.value;
                selectElement=document.querySelector('#d');
            var b=selectElement.value;
            
           
                            if (a === b) {
                 window.alert("Incorrect selection Select correctly!!");
                 window.location.replace("searchschedule2.php");
            }
            }
            

        </script>
    </form>

        </div>
		

</body>
</html>
<?php
if(isset($_POST["search"])){
    require "search2.php";
}
?>