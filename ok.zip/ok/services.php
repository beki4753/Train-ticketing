
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="Affordable and professional web design">
   <meta name="keywords" content="web design, affordable web design, professional web design">
   <meta name="author" content="Brad Traversy">
    <title>Train Ticketing | Services</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="beauty.css">
  
  </head>
  <body> 
   

  <header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="customerannouncement.php">Announcment</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="adminlog.php">Login</a></li>
            <li><a href="./Admin/send.php" id="send">Pay</a></li>
          </ul>
        </nav>
      </div>
    </header>
<br/><br/>
<br/><br/>

    <section id="newsletter">
      <div class="container">

        
      </div>
    </section>

    <section id="main">
      <div class="container" >
        
        <article id="main-col">
          <h1 class="page-title">Services</h1>
          <ul id="services">
            <li>
              <h3>Hotel Reservation</h3>
              <p>we can reserve hotels if you want. There are hotels ranks from one star to three stars.The hotels have shipshape services. </p>
        <p>Pricing: $200 - $1,000</p>
            </li>
            <li>
              <h3>Taxi service</h3>
              <p>If you want a taxi when you arrive to your destination ,we are delighted to give you taxi service. there are heaps of taxi's that are working with us. </p>
        <p>Pricing: $1 per kilometer </p>
            </li>
            <li>
              <h3>Contact a Guider</h3>
              <p> if you are a tourist we can contact you tour companies(guiders) that cooperates with us.</p>
        <p>Pricing: it is determined when you select what places to viit.</p>
            </li>
          </ul>
        </article>


      </div>
    </section>

    <footer>
     <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>
    <script src="beauty.js"></script>
  </body>
</html>