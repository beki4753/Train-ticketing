<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
</head>
<body >
	
		<div class="container">
            <form action="viewschedule.php" method="post">
        <input type="date" name="datee" required="">
        <input type="reset" name="reset" value="reset" class="sub2">
        <input type="submit" name="insert" value="search" class="sub" >

    </form>

        </div>
		

</body>
</html>
<?php
if(isset($_POST["search"])){
    require "viewschedule.php";
}
?>