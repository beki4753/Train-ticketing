<?php
include("./Admin/ticket.php");
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="description" content="train metro ticketing system">
   <meta name="keywords" content="train ticketing,train metro ticketing system , ticketing system">
   
   <meta name="author" content="Brad Traversy">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="animate.css">
    <link rel="stylesheet" href="beauty.css">

  </head>

  <body>
    <header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php" >Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="customerannouncement.php">Announcment</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="adminlog.php">Login</a></li>
            <li><a href="" id="ticket">Ticket</a></li>
            <li><a href="./Admin/send.php" id="send">Pay</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
      <div class="container">
        <h1 style="font-family:Brush Script m7; font-size: 80px;text-shadow: 2px 2px 4px #000; " >Train/ Metro Ticketing System</h1>
        <p style="font-family: Georgia; color:rgba(255,255,255,0.7); text-shadow: 2px 2px 4px #000; font-size: 35px;">According to our system we are having some features which will make users to access the system smoothly. </p>
      </div>
    </section>

    <section id="newsletter">
      <div class="container">
        <h1 style="font-family: Lucida Handwriting;">Reservation</h1>
          
          <a class="button_1" href="searchschedule.php"> Reserve Now  </a> 
        
      </div>
    </section>

    <section id="boxes">
      <div class="container">
        <div class="box">
          <a title="essay on train"; href="https://www.vedantu.com/english/train-journey-essay"><img src="tt.jpg"></a>
          <b>
		  <h3>TRAIN DESCRIPTION</h3>
          <p><i>A train is not just a vehicle. It carries emotion; it carries the joy of moving forward, it carries the thrill of speed. Many times, when we read about any train journey in a book or on the internet, we are told the story of traveling in inter-state trains. However, a local train-journey is not devoid of thrill, adventure and happiness either. There is a thrill of being on time, the adventure of exploring local sites and the happiness of being able to travel comfortably and safely.</i> </p>
        </b>
		</div>
        <div class="box">
         <a href="https://www.haileresorts.com/adama-resort/#" title="Additional info"> <img src="Haile-Resort-Adama.JPG"></a>
          <h3>HAILE RESORT ADAMA</h3>
          <p><b>Haile Hotels and Resorts are named after the Ethiopian Legend long-distance runner Major Haile Gebreselassie. His renowned phrase “it is Possible!” has made Haile Hotels & Resorts a reality and keeps boosting the hospitality industry across Ethiopia & East Africa. We aspire to be the benchmark indigenous hotel chain developer and operator in East Africa by 2025.

It all started in 2010 when Haile Resort – Hawassa joined the hospitality industry by opening a Luxurious 4-Star resort. Ever since, it expanded by opening other SIX RESORTS & ONE HOTEL in different cities that have amazing geographical, historical, and cultural values.</b></p>
        </div>
        <div class="box">
          <img src="inside.jpg">
          <h3>Interal Look</h3>
          <p style="font-family: Times New Roman; font-size: 20px;"><b>
          "Ride the Train: The Ultimate in Comfort, Convenience, and Connectivity. Free Wifi and USB Cable Ports Included!"
         </b></p>
        </div>
      </div>
    </section>

    <footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>
    <script src="beauty.js"></script>
    <script>
function openModal() {
  var modal = document.getElementById("myModal");
  modal.style.display = "block";
}

const ticketBtn = document.getElementById("ticket");
ticketBtn.addEventListener('click', openModal);
ticketBtn.addEventListener('click', function(event){
  event.preventDefault();
});

    </script>
     </body>
</html>