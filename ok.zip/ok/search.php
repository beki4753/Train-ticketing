
<?php
$fromm =$_POST['source'];
$too =$_POST['destination'];
$datee =$_POST['datee'];

// $search = $_POST['datee'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "select * from schedule where date like '%$datee%'";

$result = $conn->query($sql);

if ($result->num_rows > 0){
	$row = $result->fetch_assoc(); 
// while($row = $result->fetch_assoc() ){
	if($fromm ==$row["source"] && $too ==$row["destination"] && $datee ==$row["date"]  ){
    // echo '<script type="text/javascript">';
    // echo 'window.alert("Train Found  Price is 500birr Pleas pay by banck and send TT number");';
    
    
    // echo 'window.location.href="reservation.php"';
    // echo '</script>';
         // header('Location: found.php?data=$row["date"] ');
          //other way to send data is bellow
          session_start();
          $_SESSION['data']=$datee;
          header("Location: found.php");
	}else{
        include 'popup.php';
        
        // Show the "mymodal" div using JavaScript
        echo '<script>';
        echo 'var modal = document.getElementById("myModal");';
        echo 'modal.style.display = "block";';
        echo '</script>';
	}
	// echo $row["source"]."  ".$row["destination"]."  ".$row["date"]." ".$row["time"]."<br>";
// }
} else {
    include 'popup.php';
        
    // Show the "myModal" div using JavaScript
    echo '<script>';
    echo 'var modal = document.getElementById("myModal");';
    echo 'modal.style.display = "block";';
    echo '</script>';
}

$conn->close();



?>