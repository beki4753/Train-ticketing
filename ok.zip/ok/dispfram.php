<?php
session_start();
$count =$_SESSION['count'];
$number=$_SESSION['wenber'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}


// echo '<script>';
// echo 'alert("'.$$number.'");';
// echo '</script>';
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Seats</title>
<!-- <link rel="stylesheet" type="text/css" href="progress.css"> -->
<style>
      
      * {
        margin: 0;
        border: 0;
        box-sizing: border-box;
      }
      @import url("https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700");
      @import url("https://fonts.googleapis.com/css?family=Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i");
      
      
      :root {
        --font-roboto: "Roboto Slab", serif;
        --font-raleway: "Raleway", sans-serif;
      }
      
      body {
        font-family: var(--font-roboto);
        background-color: #fff; //212426
      }
      .outer{
    width: 160px;
    height: 160px;
    border-radius: 50%;
    padding: 20px;
   box-shadow: 6px 6px 10px -1px rgba(0,0,0,0.15),
               -6px -6px 10px -1px rgba(255,255,255,0.7);

}
.inner{
    width: 120px;
    height: 120px;
    border-radius: 50%;
    box-shadow: inset 4px 4px 6px -1px rgba(0,0,0,0.2),
               inset -4px -4px 6px -1px rgba(255,255,255,0.7),
               -0.5px -0.5px 0px rgba(255,255,255,1),
               0.5px 0.5px 0px rgba(0,0,0,0.05),
               0px 12px 10px -10px rgba(0,0,0,0.05);
display: flex;
align-items:center;
justify-content: center;
}

circle{
    fill: none;
    stroke: url(#GradientColor);
    stroke-width:20px;
    stroke-dasharray: 472;
    stroke-dashoffset: 472; /*used to animat the cicrcle */
    animation: anim 2s linear forwards;
}

svg{ position: absolute;
top: 0;
left: 0;

}

@keyframes anim{
    100%{
    stroke-dashoffset: 165;  
    }
}
      .app {
        padding: 4rem;
      
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
      }
      
      .h1 {
        float: center;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        letter-spacing: 0.9px;
        background: linear-gradient(
          90deg,
          rgba(0, 0, 0, 1) 0%,
          rgba(0, 00, 0, 0.2) 100%
        );
        background-clip: text;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        width: fit-content;
        padding-left: 60px;
        margin-top: 100px;
      }
      
      
      .Container {
        width: 100%;
        margin-top: 3rem;
      
        display: flex;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
      }
      
      .movie {
        width: 310px;
        height: 460px;
        margin: 1.5rem;
      background-color: white;
        position: relative;
        border-radius: 12px;
        overflow: hidden;
        border: none;
      
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0, 1);
        box-shadow: 0px 13px 10px -7px rgba(0, 0, 0, 0.1);
      }
      
      @media screen and (max-width: 600px) {
        .app {
          padding: 4rem 2rem;
        }
      
      }
      
      @media screen and (max-width: 400px) {
        .app {
          padding: 4rem 1rem;
        }
      
        .h1 {
          font-size: 2rem;
        }
      
        .container {
          margin-top: 2rem;
        }
      
        .movie {
          width: "100%";
          margin: 1rem;
        }
      }
      .empty{
        display: block;
  font-size: 1.5rem;
  color: rgba(0,0,0,0.7);
  font-family: var(--font-raleway);
  float: center;
  align-items :center;
  justify-content: center;
  padding: 10px;
  padding-left: 60px;

}

          </style>
</head>
<body >
<div >
    <h1 class="h1">Seat info</h1>
    <label class="empty">Place: <?php echo $number ?></label>
    <label class="empty">Left-Place: <?php echo $number-$count ?></label>
</div>
    </body>
</html>
