 <?php
 session_start();
try{

$conn =mysqli_connect('localhost','root','','project') or die('Unable to connect');
}catch(Exception $e){
  echo "Message".$e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta name="description" content="train metro ticketing system">
   <meta name="keywords" content="train ticketing,train metro ticketing system , ticketing system">
   
   <meta name="author" content="Brad Traversy">
    <title>login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="beauty.css">
    <style>
@media screen and (max-width: 768px){
  .div {
          margin-left: 16vw;
width: 50vw;
height: 50vh;
        }
        .div .th{
          margin-left: 25vw;
       }

        .div .df{
          margin-left: 25vw;
        }
        .div .db{
margin-left: 30vw;
        }
        .tt{
    height: 8vh;
    width:70vw ;
    margin: 0px;

        }
        
}
      @media screen and (max-width: 320px){
        .div {
          margin-left: 0.9rem !important;
width: 50vw !important;
height: 50vh !important;
        }
        .div .th{
          margin-left: 30vw;
       }

        .div .df{
          margin-left: 25vw;
        }
        .div .db{
margin-left: 30vw;
        }

        .tt{
          
    height: 8vh !important;
    width:90vw !important;
    margin: 0px !important;

        }
      }
      </style>
</head>

<body style="background-size: 100% 100%;">
   
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
            <li class="current"><a href="index.php">Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="adminlog.php">Admin</a></li>
          </ul>
        </nav>
      </div>
    </header>



    <div class="div">
        <br><br>
        <br><br>
        <br><br>
        <h1 class="th">Login</h1>
       <form action="" method="post">
       <b><label class="df">Email:</label></b>  <br><br>
         <input type="email" placeholder="name@gmail.com" class="tt" name="email">
        <br><br>
       <b><label class="df">Password:</label></b>   <br><br>
         <input type="password" placeholder="Password" class="tt" name="pass">
         <br><br>
 <input type="submit" class="db" value="LOGIN" name="login">
    </form>
    
    <br><br>
    <pre><a class="si" href="signup.php">SIGN UP</a></pre>
    <br><br><br><br>
    </div>
 <?php
 

if(isset($_POST['login'])){
  $username=$_POST['email'];
  $pass=$_POST['pass'];
  
  $select= mysqli_query($conn,"SELECT*FROM new_signup WHERE email ='$username' AND password='$pass' ");
  $row = mysqli_fetch_array($select);
  if(is_array($row)){
    $_SESSION["Email"] = $row['email'];
    $_SESSION["password"] = $row['password'];
    try{
      if($_SESSION['Email']){
        echo '<script type="text/javascript">';
        echo ' window.location.replace("customerreserv.php");';
        echo '</script>';
       
    }
    }catch(Exception $e){
      echo "Message".$e->getMessage();
    }
  }else{
    echo '<script type="text/javascript">';
    echo 'alert("Invalid Username or Password");';
    echo '</script>';
 }


}
?> 





   <script src="beauty.js"></script>
</body>
</html>