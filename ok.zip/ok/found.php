<?php
// $data=$_GET['data'];

//other way to recive data is bellow
session_start();
function gregorian_to_ethiopian($date) {
  // Get Gregorian year, month, and day
  list($year, $month, $day) = explode('-', $date);
  
  // Determine if Gregorian year is a leap year
  $is_leap_year = ($year % 4 == 0 && $year % 100 != 0) || ($year % 400 == 0);
  
  // Determine Ethiopian offset
  $offset = $is_leap_year ? 1 : 0;
  
  // Convert Gregorian date to Ethiopian date
  $ethiopian_year = $year - (($month < 9 || ($month == 9 && $day < 11)) ? 8 : 7);
  $ethiopian_month = ($month - 1 + $offset) % 13 + 1;
  $ethiopian_day = $day + $offset;
  
  // Return Ethiopian date in the format Y-M-D
  return sprintf('%04d-%02d-%02d', $ethiopian_year, $ethiopian_month, $ethiopian_day,);
}
$data=$_SESSION['data'];
$servername = "localhost";
$username = "root";
$password = "";
$db = "project";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}
$sql = "select N_seats from train ";
$result2 = $conn->query($sql);

if ($result2->num_rows > 0){
   //$row = $result->fetch_assoc(); 
while($row2 = $result2->fetch_assoc() ){
    $number= $row2["N_seats"];
    $_SESSION['wenber']= $number;
}
}
date_default_timezone_set("Africa/Addis_Ababa");
$current_time=date("h:i");
$now= strtotime($current_time);
// echo "<script>";
// echo "alert('$now');";
// echo "</script>";
$query = "SELECT * FROM request WHERE expiry_time < '$now'"; 
$result = mysqli_query($conn, $query); 
if (mysqli_num_rows($result) > 0) { 
    while($row = $result->fetch_assoc()) { 
        $request_id = $row['Request_Id']; 
        // Check if the request ID is registered in the other table 
        $sql2 = "SELECT Request_Id FROM checked WHERE status = 'cancelled' AND Request_Id='$request_id'"; 
        $result2 = $conn->query($sql2); 
        if ($result2->num_rows == 0) { 
            // Delete the record from the requests table 
            $sql3 = "DELETE FROM requests WHERE Request_Id = $request_id"; 
            $result3 = $conn->query($sql3); 
        } 
      }
     } 
 $sql = "select * from schedule where date like '%$data%'";
 $sql2 = "SELECT SUM(`num_person`) AS totalPlacesReserved 
 FROM `request` 
 WHERE `date` like '%$data%'";
//$sql = "SELECT DATE_FORMAT(your_time_field, '%h:%i %p') AS formatted_time FROM your_table";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0){
	//$row = $result->fetch_assoc(); 
while($row2 = $result2->fetch_assoc() ){
  if($row2["totalPlacesReserved"]>=100){
    echo '<script>';
   echo 'alert("Train is full!");';
   echo 'window.location.href="searchschedule.php";';
   echo ' </script>';
  }else{
    $_SESSION['count']=$row2["totalPlacesReserved"];
  }
   
}
}

$result = $conn->query($sql);
// $database = array();

if ($result->num_rows > 0){
	//$row = $result->fetch_assoc(); 
while($row = $result->fetch_assoc() ){
    $sou=$row["source"];
    $desti=$row["destination"];
    // $database[]=$row["date"];
    $dat=$row["date"];
    $tim=$row["time"];
    $_SESSION['source']=$sou;
    $_SESSION['destination']=$desti;
    $_SESSION['date']=$dat;
    $_SESSION['time']=$tim;
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
    <link rel="stylesheet" type="text/css" href="s.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="beauty.css">
    <style>
      
* {
  margin: 0;
  border: 0;
  box-sizing: border-box;
}
@import url("https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700");
@import url("https://fonts.googleapis.com/css?family=Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i");


:root {
  --font-roboto: "Roboto Slab", serif;
  --font-raleway: "Raleway", sans-serif;
}
.darkk{
	padding:15px;
	
	color:#ffffff;
	margin-top:10px;
	margin-bottom:10px;
  /* width: 100%;
  height: 110%; */
  font-size: 1.56rem;
  letter-spacing: 0.9px;
  background: linear-gradient(
    90deg,
    rgba(249, 211, 180, 1) 0%,
    rgba(249, 211, 180, 0) 100%
  );
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  width: fit-content;
  }
.span{
	color: #fff;
	font-size: 1.2rem;
	font-family: 'Times New Roman', Times, serif;
	text-transform: capitalize;
margin: 0%;
padding: 0;
display: inline;
}
 .h1{
margin: 0% 15%;
	color:#fff !important;
	font-size: 3rem;
	font-family: 'Times New Roman', Times, serif;
	text-transform: uppercase;
	display: block;
	top:0;
}
 h2{
	color: rgba(255,255,255,0.7);
	text-transform: capitalize;
	margin: 0%;
	padding: 5px;
}
 i{
	font-family: 'Times New Roman', Times, serif;
	color: aliceblue;
	font-size: 15px;
	margin-top: 20px;
}
body {
  font-family: var(--font-roboto);
  
}
.beu{
  
	display: block;
	float: center;
justify-content: center;
align-items: center;
padding-left: 20px;
padding-top: 5px;
flex-wrap: nowrap;
}
.app {
  padding: 4rem;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

/* .h1 {
  font-size: 3rem;
  letter-spacing: 0.9px;
  background: linear-gradient(
    90deg,
    rgba(249, 211, 180, 1) 0%,
    rgba(249, 211, 180, 0) 100%
  );
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  width: fit-content;
} */


.Container {
  width: 100%;
  margin-top: 5rem;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.movie {
  width: 310px;
  height: 460px;
  margin: 1.5rem;
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  border: none;

  background: #212426;
  background-size: 100% 100%;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0, 1);
  box-shadow: 0px 13px 10px -7px rgba(0, 0, 0, 0.1);
}

@media screen and (max-width: 600px) {
  .app {
    padding: 4rem 2rem;
  }

}

@media screen and (max-width: 400px) {
  .app {
    padding: 4rem 1rem;
  }

  .h1 {
    font-size: 2rem;
  }

  .container {
    margin-top: 2rem;
  }

  .movie {
    width: "100%";
    margin: 1rem;
  }
}
    </style>
</head>
<body style="background:url('blacktrain.jpg');
	background-size: 100% 100%;
background-repeat: no-repeat;
background-position: fixed;" >
<div class="App">
<header>
      <div class="container">
        <div id="branding" class="title">
          <h1><span class="highlight">Train</span>Ticketing</h1>
        </div>
        <!-- <button type="button"  onclick="toggleNav()"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
        <button type="button" class="togler " id="navbar-toggle"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        <nav class="navbar">
          <ul>
          <li class="current"><a href="index.php" >Home</a></li>

            <li class="current" id="blink"><a href="reservation.php" ><span >&#x1F4C6;</span>&nbsp;Reserv</a></li>
          </ul>
        </nav>
    
    </header>
    <div class="Container">
      <div class="movie">
    <h1 class="h1">Train Found</h1>
    
    <div class="beu">
      <!-- <h2 >Origin:</h2> -->
      <?php echo "<h2 ><u>&#8226;&nbsp;Origin:</u>&nbsp;&nbsp;<span>$sou</span></h2>";?>
    </div>

    <div class="beu">
        <!-- <h2 >Destination:</h2> -->
        <?php echo "<h2><u>&#8226;&nbsp;Destination:</u>&nbsp;&nbsp;<span>$desti</span></h2>";?>
     </div>

     <div class="beu">
<!-- <h2 >Date:</h2> -->
<?php


// $ethiopian_dates = array();
// // Loop through the dates array
// foreach ($database as $datee) {
//     $ethiopian_dates[] = gregorian_to_ethiopian($datee);
// }
$ethiopian_date=$dat;
// Display the Ethiopian dates
// foreach ($ethiopian_dates as $ethiopian_date) {
    echo "<h2><u>&#8226;&nbsp;Date:</u>&nbsp;&nbsp;<span>$ethiopian_date</span></h2>";
// }

// $ethiopian_date = gregorian_to_ethiopian($dat);
?>
</div>

<div class="beu">
<!-- <h2 >Time:</h2> -->
<?php $formatted_time = date('h:i A', strtotime($tim)); echo "<h2><u>&#8226;&nbsp;Time:</u>&nbsp;&nbsp;<span>$formatted_time<span></h2>";?>
</div>

<i>"Let the train take you on a journey of discovery. Sit back, relax and enjoy the ride as you make unforgettable memories along the way."</i>
</div>
<div class="movie">
<iframe src="seatnumber.php" frameborder="0" width="500" height="350";  ></iframe>
</div>
<div class="movie">
<iframe src="dispfram.php" frameborder="0" width="500" height="350";  ></iframe>

</div>
        <aside class="movie">
          <div class="darkk">
            <h3 style="text-decoration: underline;">Payment Info</h3>
            <p style="text-transform: capitalize;">Price is 500birr/person <br/>Pleas pay by bank and copy Txn Id <br/><b style="text-transform: uppercase; font-size: 1rem; color: #fff; text-decoration: underline;">possible ways</b> <br/> &#8226;TELE BIRR<br/> &#8226;CBE BIRR</p>
            <p>CBE ACC 1000228891097</p>
            <p>Phone: 0953753505</p>
            
          </div>
        </aside>
</div>
        <?php }
        } else {
          include "popup.php";
          echo '<script type="text/javascript">';
          echo 'var modal = document.getElementById("myModal");';
          echo 'modal.style.display = "block";';
          echo 'window.location.href="reservation.php"';
          echo '</script>';
    }
    mysqli_close($conn);?>
  </div>
  <footer>
      <p>Train Ticketing, Copyright &copy; 2022</p>
    </footer>		
        <script src="beauty.js"></script>
  
</body>
</html>