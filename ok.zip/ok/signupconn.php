<?php
$fname =$_POST['fname'];
$lname =$_POST['lname'];
$email =$_POST['email'];
$tel =$_POST['phone'];
$password =$_POST['pass'];
$addr =$_POST['address'];
//database connection
$conn = new mysqli('localhost','root','','project');
if($conn->connect_error){
	die('Connection Failed : '.$conn->connect_error);//making unique email and password not to duplicate
}else{
       try{
	$stmt = $conn->prepare("insert into new_signup(email,password,fname,lname,phone,address)
		values(?,?,?,?,?,?)");
	$stmt->bind_param("ssssis",$email,$password,$fname,$lname,$tel,$addr);
	$stmt->execute();
 
	echo "<h1>registration successfully...</h1>";
	header("Location: customerreserv.php");
	$stmt->close();
	$conn->close();
       }catch(Exception $e){
       	echo "Message".$e->getMessage();
       }

}
?>